//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BtGMKMeY.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BFF9ugbK.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BFF9ugbK.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BnY51Z29.js"]
	}
} });
//#endregion
export { tsrStartManifest };
