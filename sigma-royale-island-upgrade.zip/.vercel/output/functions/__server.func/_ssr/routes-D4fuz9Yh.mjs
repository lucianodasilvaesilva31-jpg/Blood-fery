import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as SphereGeometry, S as ShaderMaterial, _ as Points, a as CircleGeometry, b as SRGBColorSpace, c as FogExp2, d as IcosahedronGeometry, f as Mesh, g as PerspectiveCamera, h as OctahedronGeometry, i as BufferGeometry, l as Group, m as MeshStandardMaterial, n as BoxGeometry, o as CylinderGeometry, p as MeshBasicMaterial, r as BufferAttribute, s as DirectionalLight, t as WebGLRenderer, u as HemisphereLight, v as PointsMaterial, w as Vector3, x as Scene, y as RingGeometry } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D4fuz9Yh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ctx = null;
function unlockAudio() {
	if (typeof window === "undefined") return;
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return;
	if (!ctx) ctx = new AC();
	ctx.resume();
}
function tone(freq, dur, type, gain) {
	if (!ctx) return;
	const now = ctx.currentTime;
	const osc = ctx.createOscillator();
	const amp = ctx.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, now);
	amp.gain.setValueAtTime(gain, now);
	amp.gain.exponentialRampToValueAtTime(1e-4, now + dur);
	osc.connect(amp);
	amp.connect(ctx.destination);
	osc.start(now);
	osc.stop(now + dur + .02);
}
function playEvent(type) {
	if (type === "shot") {
		tone(210, .05, "square", .03);
		tone(90, .07, "sawtooth", .02);
		return;
	}
	if (type === "hit") {
		tone(140, .06, "triangle", .03);
		return;
	}
	if (type === "kill") {
		tone(320, .08, "square", .03);
		tone(480, .1, "triangle", .025);
		return;
	}
	if (type === "muro") {
		tone(180, .09, "triangle", .04);
		return;
	}
	tone(620, .07, "sine", .035);
}
var BEST_KEY = "sigma-royale-best";
var COVERS = [
	{
		x: 14,
		z: -6,
		yaw: .7,
		hx: 1.8,
		hz: .9
	},
	{
		x: -9,
		z: 7,
		yaw: .3,
		hx: 1.4,
		hz: 1.3
	},
	{
		x: 7,
		z: 14,
		yaw: 1.1,
		hx: 1.5,
		hz: .8
	},
	{
		x: -14,
		z: -10,
		yaw: .2,
		hx: 1.2,
		hz: 1.2
	}
];
var GUNS = {
	pistol: {
		dmg: 28,
		rate: .26,
		mag: 12,
		reload: 1.15,
		spread: .045,
		pellets: 1,
		range: 28
	},
	ar: {
		dmg: 19,
		rate: .1,
		mag: 30,
		reload: 1.4,
		spread: .02,
		pellets: 1,
		range: 36
	},
	shotgun: {
		dmg: 15,
		rate: .7,
		mag: 5,
		reload: 1.85,
		spread: .16,
		pellets: 6,
		range: 13
	}
};
var ZONE_RADII = [
	40,
	28,
	18,
	11,
	6
];
var GUN_LABEL = {
	pistol: "Pistola",
	ar: "Fuzil",
	shotgun: "Escopeta"
};
var SERVER_HUD = {
	phase: "boot",
	hp: 200,
	armor: 0,
	alive: 11,
	total: 11,
	kills: 0,
	place: 0,
	best: 0,
	gun: "pistol",
	mag: 12,
	reserve: 36,
	reloading: false,
	meds: 0,
	muros: 0,
	crouch: false,
	channel: false,
	outside: false,
	shrinking: false,
	zoneIn: 16,
	banner: "",
	tone: "ok",
	playTime: 0,
	pulseReady: true,
	landed: false
};
function loadBest() {
	if (typeof window === "undefined") return 0;
	try {
		const n = Number(localStorage.getItem("sigma-royale-best") || "0");
		return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
	} catch {
		return 0;
	}
}
function saveBest(n) {
	try {
		localStorage.setItem(BEST_KEY, String(n));
	} catch {}
}
function fighter(id, x, z, y) {
	return {
		id,
		x,
		z,
		y,
		vy: 0,
		yaw: 0,
		pitch: 0,
		hp: 200,
		armor: 0,
		alive: true,
		landed: false,
		landX: x,
		landZ: z,
		gun: "pistol",
		mag: 12,
		reserve: 48,
		reload: 0,
		fireCd: 0,
		meds: 0,
		muros: 0,
		muroCd: 0,
		crouch: false,
		channel: 0,
		pulse: 0,
		pulseCd: 0,
		speed: 0,
		glooCd: 0,
		side: null,
		sideMag: 0,
		sideReserve: 0
	};
}
function ringPoint(i, n, minR, maxR) {
	const a = i / n * Math.PI * 2 + Math.random() * .35;
	const r = minR + Math.random() * (maxR - minR);
	return {
		x: Math.cos(a) * r,
		z: Math.sin(a) * r
	};
}
function createSim(best = loadBest()) {
	let nextId = 1;
	const drop = ringPoint(0, 1, 12, 22);
	const player = fighter(nextId++, drop.x, drop.z, 32);
	player.reserve = 36;
	player.yaw = Math.atan2(drop.x, drop.z);
	const bots = [];
	for (let i = 0; i < 10; i++) {
		const p = ringPoint(i, 10, 10, 30);
		const b = fighter(nextId++, p.x, p.z, 26 + Math.random() * 10);
		b.hp = 160;
		if (i % 3 === 0) {
			b.gun = "ar";
			b.mag = 30;
			b.reserve = 60;
		}
		b.muros = 1;
		bots.push(b);
	}
	const loot = [];
	const kinds = [
		"ar",
		"ar",
		"shotgun",
		"shotgun",
		"vest",
		"vest",
		"vest",
		"med",
		"med",
		"med",
		"muro",
		"muro",
		"ammo",
		"ammo",
		"ammo"
	];
	for (const kind of kinds) {
		const p = ringPoint(loot.length, kinds.length, 4, 34);
		loot.push({
			id: nextId++,
			kind,
			x: p.x,
			z: p.z
		});
	}
	return {
		epoch: 1,
		phase: "boot",
		time: 0,
		playTime: 0,
		player,
		bots,
		muros: [],
		loot,
		zoneX: (Math.random() - .5) * 10,
		zoneZ: (Math.random() - .5) * 10,
		zoneR: ZONE_RADII[0],
		zoneTx: 0,
		zoneTz: 0,
		zoneTr: ZONE_RADII[1],
		zoneT: 18,
		shrinking: false,
		stage: 0,
		nextId,
		kills: 0,
		place: 0,
		best,
		won: false,
		shake: 0,
		banner: "",
		bannerT: 0,
		tone: "ok",
		events: []
	};
}
var runtime = {
	sim: createSim(),
	keys: /* @__PURE__ */ new Set(),
	held: /* @__PURE__ */ new Set(),
	stick: {
		x: 0,
		y: 0,
		active: false
	},
	lookDx: 0,
	lookDy: 0,
	fireHeld: false,
	spaceWas: false,
	pulses: {
		jump: false,
		muro: false,
		med: false,
		swap: false,
		crouch: false,
		pulse: false
	},
	input: emptyInput()
};
function emptyInput() {
	return {
		mx: 0,
		mz: 0,
		lookDx: 0,
		lookDy: 0,
		fire: false,
		jump: false,
		muro: false,
		med: false,
		swap: false,
		crouch: false,
		pulse: false
	};
}
var listeners = /* @__PURE__ */ new Set();
var snap = toSnap(runtime.sim);
var sig = "";
function signature(s) {
	const p = s.player;
	const outside = Math.hypot(p.x - s.zoneX, p.z - s.zoneZ) > s.zoneR;
	return [
		s.phase,
		Math.ceil(p.hp),
		Math.ceil(p.armor),
		aliveCount(s),
		s.kills,
		s.place,
		s.best,
		p.gun,
		p.mag,
		p.reserve,
		p.reload > 0 ? 1 : 0,
		p.meds,
		p.muros,
		p.crouch ? 1 : 0,
		p.channel > 0 ? 1 : 0,
		outside ? 1 : 0,
		s.shrinking ? 1 : 0,
		Math.ceil(s.zoneT),
		s.bannerT > 0 ? s.banner : "",
		s.tone,
		Math.floor(s.playTime),
		p.pulseCd <= 0 ? 1 : 0,
		p.landed ? 1 : 0,
		s.won ? 1 : 0
	].join("|");
}
function aliveCount(s) {
	let n = s.player.alive ? 1 : 0;
	for (const b of s.bots) if (b.alive) n += 1;
	return n;
}
function toSnap(s) {
	const p = s.player;
	return {
		phase: s.phase,
		hp: Math.max(0, Math.ceil(p.hp)),
		armor: Math.max(0, Math.ceil(p.armor)),
		alive: aliveCount(s),
		total: 11,
		kills: s.kills,
		place: s.place,
		best: s.best,
		gun: p.gun,
		mag: p.mag,
		reserve: p.reserve,
		reloading: p.reload > 0,
		meds: p.meds,
		muros: p.muros,
		crouch: p.crouch,
		channel: p.channel > 0,
		outside: p.landed && Math.hypot(p.x - s.zoneX, p.z - s.zoneZ) > s.zoneR,
		shrinking: s.shrinking,
		zoneIn: Math.max(0, Math.ceil(s.zoneT)),
		banner: s.bannerT > 0 ? s.banner : "",
		tone: s.tone,
		playTime: Math.floor(s.playTime),
		pulseReady: p.pulseCd <= 0,
		landed: p.landed
	};
}
function subscribe(listener) {
	listeners.add(listener);
	return () => listeners.delete(listener);
}
function getHud() {
	return snap;
}
function getServerHud() {
	return SERVER_HUD;
}
function publish(force = false) {
	const next = signature(runtime.sim);
	if (!force && next === sig) return;
	sig = next;
	snap = toSnap(runtime.sim);
	for (const listener of listeners) listener();
}
function edge(code) {
	const down = runtime.keys.has(code);
	const was = runtime.held.has(code);
	if (down) runtime.held.add(code);
	else runtime.held.delete(code);
	return down && !was;
}
function readInput() {
	const keys = runtime.keys;
	const stick = runtime.stick;
	let mx = 0;
	let mz = 0;
	if (stick.active) {
		mx = stick.x;
		mz = stick.y;
	} else {
		if (keys.has("KeyW") || keys.has("ArrowUp")) mz += 1;
		if (keys.has("KeyS") || keys.has("ArrowDown")) mz -= 1;
		if (keys.has("KeyA") || keys.has("ArrowLeft")) mx -= 1;
		if (keys.has("KeyD") || keys.has("ArrowRight")) mx += 1;
	}
	const len = Math.hypot(mx, mz);
	if (len > 1) {
		mx /= len;
		mz /= len;
	}
	if (Math.abs(mx) < .14) mx = 0;
	if (Math.abs(mz) < .14) mz = 0;
	const space = keys.has("Space");
	const input = {
		mx,
		mz,
		lookDx: runtime.lookDx,
		lookDy: runtime.lookDy,
		fire: runtime.fireHeld || keys.has("KeyF"),
		jump: runtime.pulses.jump || space && !runtime.spaceWas,
		muro: runtime.pulses.muro || edge("KeyG"),
		med: runtime.pulses.med || edge("KeyE"),
		swap: runtime.pulses.swap || edge("KeyQ"),
		crouch: runtime.pulses.crouch || edge("KeyC"),
		pulse: runtime.pulses.pulse || edge("KeyV")
	};
	runtime.spaceWas = space;
	runtime.lookDx = 0;
	runtime.lookDy = 0;
	runtime.pulses.jump = false;
	runtime.pulses.muro = false;
	runtime.pulses.med = false;
	runtime.pulses.swap = false;
	runtime.pulses.crouch = false;
	runtime.pulses.pulse = false;
	runtime.input = input;
	return input;
}
function tap(kind) {
	runtime.pulses[kind] = true;
}
function begin() {
	const best = runtime.sim.best;
	const epoch = runtime.sim.epoch + 1;
	const fresh = createSim(best);
	fresh.epoch = epoch;
	fresh.phase = "drop";
	fresh.banner = "Queda livre";
	fresh.bannerT = 2.2;
	fresh.tone = "ok";
	runtime.sim = fresh;
	publish(true);
}
function say(sim, text, tone = "ok", t = 1.3) {
	sim.banner = text;
	sim.bannerT = t;
	sim.tone = tone;
}
function notePlace(sim, place) {
	sim.place = place;
	sim.phase = "over";
	if (sim.best === 0 || place < sim.best) {
		sim.best = place;
		saveBest(place);
	}
}
function basis$1(yaw) {
	return {
		fx: -Math.sin(yaw),
		fz: -Math.cos(yaw),
		rx: Math.cos(yaw),
		rz: -Math.sin(yaw)
	};
}
function clampArena(ent) {
	const d = Math.hypot(ent.x, ent.z);
	if (d > 46) {
		ent.x = ent.x / d * 46;
		ent.z = ent.z / d * 46;
	}
}
function pushOut(ent, box) {
	const { fx, fz, rx, rz } = basis$1(box.yaw);
	const lx = (ent.x - box.x) * rx + (ent.z - box.z) * rz;
	const lz = (ent.x - box.x) * fx + (ent.z - box.z) * fz;
	if (Math.abs(lx) >= box.hx || Math.abs(lz) >= box.hz) return;
	const px = box.hx - Math.abs(lx);
	const pz = box.hz - Math.abs(lz);
	if (px < pz) {
		const s = lx >= 0 ? 1 : -1;
		ent.x += rx * s * px;
		ent.z += rz * s * px;
	} else {
		const s = lz >= 0 ? 1 : -1;
		ent.x += fx * s * pz;
		ent.z += fz * s * pz;
	}
}
function pushSolids(sim, ent) {
	for (const c of COVERS) pushOut(ent, c);
	for (const m of sim.muros) pushOut(ent, {
		...m,
		hx: 1.45,
		hz: .62
	});
}
function rayBox(ox, oz, dx, dz, box, range) {
	const { fx, fz, rx, rz } = basis$1(box.yaw);
	const lx = (ox - box.x) * rx + (oz - box.z) * rz;
	const lz = (ox - box.x) * fx + (oz - box.z) * fz;
	const ldx = dx * rx + dz * rz;
	const ldz = dx * fx + dz * fz;
	let tmin = 0;
	let tmax = range;
	const slabs = [[
		lx,
		ldx,
		box.hx
	], [
		lz,
		ldz,
		box.hz
	]];
	for (const [p, d, h] of slabs) {
		if (Math.abs(d) < 1e-6) {
			if (p < -h || p > h) return null;
			continue;
		}
		let t1 = (-h - p) / d;
		let t2 = (h - p) / d;
		if (t1 > t2) {
			const s = t1;
			t1 = t2;
			t2 = s;
		}
		tmin = Math.max(tmin, t1);
		tmax = Math.min(tmax, t2);
		if (tmin > tmax) return null;
	}
	if (tmin < 0 || tmin > range) return null;
	return tmin;
}
function allFighters(sim) {
	return [sim.player, ...sim.bots];
}
function shoot(sim, f, extraSpread) {
	const spec = GUNS[f.gun];
	if (f.reload > 0 || f.fireCd > 0 || !f.landed || !f.alive) return;
	if (f.mag <= 0) {
		if (f.reserve > 0) f.reload = spec.reload;
		return;
	}
	f.mag -= 1;
	f.fireCd = spec.rate;
	if (f.mag <= 0 && f.reserve > 0) f.reload = spec.reload;
	const { fx, fz } = basis$1(f.yaw);
	for (let i = 0; i < spec.pellets; i++) {
		const spread = (Math.random() - .5) * 2 * (spec.spread + extraSpread);
		const yaw = f.yaw + spread;
		const dx = -Math.sin(yaw);
		const dz = -Math.cos(yaw);
		let bestT = spec.range;
		let hit = null;
		let hitMuro = null;
		for (const other of allFighters(sim)) {
			if (!other.alive || other.id === f.id || !other.landed) continue;
			const ox = other.x - f.x;
			const oz = other.z - f.z;
			const t = ox * dx + oz * dz;
			if (t < .4 || t > bestT) continue;
			if (Math.hypot(ox - dx * t, oz - dz * t) < (other.crouch ? .34 : .5)) {
				bestT = t;
				hit = other;
				hitMuro = null;
			}
		}
		for (const c of COVERS) {
			const t = rayBox(f.x, f.z, dx, dz, c, bestT);
			if (t != null && t < bestT) {
				bestT = t;
				hit = null;
				hitMuro = null;
			}
		}
		for (const m of sim.muros) {
			const t = rayBox(f.x, f.z, dx, dz, {
				...m,
				hx: 1.35,
				hz: .4
			}, bestT);
			if (t != null && t < bestT) {
				bestT = t;
				hit = null;
				hitMuro = m;
			}
		}
		const x2 = f.x + dx * bestT;
		const z2 = f.z + dz * bestT;
		sim.events.push({
			type: "shot",
			x: f.x + fx * .4,
			z: f.z + fz * .4,
			x2,
			z2
		});
		if (hitMuro) {
			hitMuro.hp -= spec.dmg;
			sim.events.push({
				type: "hit",
				x: x2,
				z: z2,
				x2,
				z2
			});
		} else if (hit) {
			hurt(sim, hit, spec.dmg, f === sim.player);
			sim.events.push({
				type: "hit",
				x: hit.x,
				z: hit.z,
				x2: hit.x,
				z2: hit.z
			});
			if (f !== sim.player) sim.shake = Math.max(sim.shake, hit === sim.player ? .35 : 0);
		}
	}
}
function hurt(sim, f, dmg, byPlayer) {
	if (!f.alive) return;
	let left = dmg;
	if (f.armor > 0) {
		const used = Math.min(f.armor, left);
		f.armor -= used;
		left -= used;
	}
	f.hp -= left;
	if (f.hp > 0) return;
	f.hp = 0;
	f.alive = false;
	sim.events.push({
		type: "kill",
		x: f.x,
		z: f.z,
		x2: f.x,
		z2: f.z
	});
	if (byPlayer && f !== sim.player) {
		sim.kills += 1;
		say(sim, `Abate · ${sim.kills}`, "ok", 1.1);
		sim.shake = .28;
	}
	if (f === sim.player) {
		const place = aliveCount(sim) + 1;
		say(sim, `Eliminado · #${place}`, "bad", 3);
		notePlace(sim, place);
	}
}
function placeMuro(sim, f) {
	if (!f.landed || f.muros <= 0 || f.muroCd > 0 || !f.alive) return;
	const { fx, fz } = basis$1(f.yaw);
	const muro = {
		id: sim.nextId++,
		x: f.x + fx * 2.15,
		z: f.z + fz * 2.15,
		yaw: f.yaw,
		hp: 220
	};
	if (Math.hypot(muro.x, muro.z) > 45.5) return;
	sim.muros.push(muro);
	f.muros -= 1;
	f.muroCd = .4;
	sim.events.push({
		type: "muro",
		x: muro.x,
		z: muro.z,
		x2: muro.x,
		z2: muro.z
	});
	if (f === sim.player) say(sim, "Muro no chão", "ok", .7);
}
function finishReload(f) {
	const need = GUNS[f.gun].mag - f.mag;
	const take = Math.min(need, f.reserve);
	f.mag += take;
	f.reserve -= take;
	f.reload = 0;
}
function giveGun(f, gun) {
	const spec = GUNS[gun];
	f.gun = gun;
	f.mag = spec.mag;
	f.reserve += spec.mag;
	f.reload = 0;
	f.fireCd = .2;
}
function takeLoot(sim, f, loot) {
	if (loot.kind === "ar" || loot.kind === "shotgun" || loot.kind === "pistol") {
		const gun = loot.kind;
		if (f.gun === "pistol" && !f.side) giveGun(f, gun);
		else if (!f.side) {
			const spec = GUNS[gun];
			f.side = gun;
			f.sideMag = spec.mag;
			f.sideReserve = spec.mag;
		} else {
			const prev = f.gun;
			const mag = f.mag;
			const reserve = f.reserve;
			giveGun(f, gun);
			f.side = prev;
			f.sideMag = mag;
			f.sideReserve = reserve;
		}
	} else if (loot.kind === "vest") {
		if (f.armor >= 100) return false;
		f.armor = 100;
	} else if (loot.kind === "med") {
		if (f.meds >= 4) return false;
		f.meds += 1;
	} else if (loot.kind === "muro") {
		if (f.muros >= 6) return false;
		f.muros += 1;
	} else if (f.reserve > 140) return false;
	else f.reserve += 36;
	sim.events.push({
		type: "pickup",
		x: loot.x,
		z: loot.z,
		x2: loot.x,
		z2: loot.z
	});
	return true;
}
function pickupNear(sim, f) {
	for (let i = sim.loot.length - 1; i >= 0; i--) {
		const loot = sim.loot[i];
		if (Math.hypot(loot.x - f.x, loot.z - f.z) > 1.35) continue;
		if (!takeLoot(sim, f, loot)) continue;
		sim.loot.splice(i, 1);
		if (f === sim.player) say(sim, loot.kind === "vest" ? "Colete" : loot.kind === "med" ? "Kit" : loot.kind === "muro" ? "Muro" : loot.kind === "ammo" ? "Munição" : GUN_LABEL[loot.kind], "ok", .8);
		return;
	}
}
function zoneDamage(stage) {
	return [
		8,
		14,
		22,
		34,
		48
	][Math.min(stage, 4)];
}
function inZone(sim, x, z) {
	return Math.hypot(x - sim.zoneX, z - sim.zoneZ) <= sim.zoneR;
}
function stepZone(sim, dt) {
	sim.zoneT -= dt;
	if (!sim.shrinking && sim.zoneT <= 0 && sim.stage < ZONE_RADII.length - 1) {
		sim.shrinking = true;
		sim.zoneT = 8;
		sim.zoneTr = ZONE_RADII[sim.stage + 1];
		const a = Math.random() * Math.PI * 2;
		const reach = Math.max(0, sim.zoneR - sim.zoneTr - 1);
		sim.zoneTx = sim.zoneX + Math.cos(a) * Math.random() * reach;
		sim.zoneTz = sim.zoneZ + Math.sin(a) * Math.random() * reach;
		say(sim, "A zona está fechando", "bad", 1.6);
	} else if (sim.shrinking) {
		const k = Math.min(1, dt / Math.max(sim.zoneT, .05));
		sim.zoneR += (sim.zoneTr - sim.zoneR) * Math.min(1, dt * .35);
		sim.zoneX += (sim.zoneTx - sim.zoneX) * k;
		sim.zoneZ += (sim.zoneTz - sim.zoneZ) * k;
		if (sim.zoneT <= 0) {
			sim.shrinking = false;
			sim.zoneR = sim.zoneTr;
			sim.zoneX = sim.zoneTx;
			sim.zoneZ = sim.zoneTz;
			sim.stage += 1;
			sim.zoneT = sim.stage >= ZONE_RADII.length - 1 ? 99 : 14;
			say(sim, "Zona fechada", "ok", 1);
		}
	}
}
function stepFighterFall(f, dt) {
	if (f.landed) return;
	f.y -= 9 * dt;
	const dx = f.landX - f.x;
	const dz = f.landZ - f.z;
	const d = Math.hypot(dx, dz) || 1;
	f.x += dx / d * 11 * dt;
	f.z += dz / d * 11 * dt;
	f.speed = 11;
	if (f.y <= 0) {
		f.y = 0;
		f.landed = true;
		f.vy = 0;
	}
}
function stepBot(sim, b, dt) {
	if (!b.alive) return;
	b.fireCd = Math.max(0, b.fireCd - dt);
	b.muroCd = Math.max(0, b.muroCd - dt);
	if (!b.landed) {
		stepFighterFall(b, dt);
		return;
	}
	if (b.reload > 0) {
		b.reload -= dt;
		if (b.reload <= 0) finishReload(b);
	}
	let foe = null;
	let foeD = 22;
	for (const other of allFighters(sim)) {
		if (!other.alive || other.id === b.id || !other.landed) continue;
		const d = Math.hypot(other.x - b.x, other.z - b.z);
		if (d < foeD) {
			foe = other;
			foeD = d;
		}
	}
	const zx = sim.zoneX - b.x;
	const zz = sim.zoneZ - b.z;
	const zd = Math.hypot(zx, zz) || 1;
	let wx = 0;
	let wz = 0;
	if (!inZone(sim, b.x, b.z) || zd > sim.zoneR - 2.5) {
		wx = zx / zd;
		wz = zz / zd;
	} else if (foe) {
		const dx = foe.x - b.x;
		const dz = foe.z - b.z;
		const d = foeD || 1;
		b.yaw = Math.atan2(-dx, -dz);
		const side = b.id % 2 === 0 ? 1 : -1;
		const toward = d > 11 ? .65 : d < 4.5 ? -.35 : .1;
		wx = -dz / d * side + dx / d * toward;
		wz = dx / d * side + dz / d * toward;
		if (foeD < 20) shoot(sim, b, .08);
		if (b.hp < 70 && b.muros > 0 && Math.random() < dt * .7) placeMuro(sim, b);
	} else {
		wx = Math.cos(sim.time * .45 + b.id) + zx / zd;
		wz = Math.sin(sim.time * .38 + b.id) + zz / zd;
		b.yaw = Math.atan2(-wx, -wz);
		if (b.gun === "pistol") pickupNear(sim, b);
	}
	const mag = Math.hypot(wx, wz) || 1;
	const sp = 6.4;
	b.x += wx / mag * sp * dt;
	b.z += wz / mag * sp * dt;
	b.speed = sp;
	pushSolids(sim, b);
	clampArena(b);
	for (const other of sim.bots) {
		if (other.id === b.id || !other.alive) continue;
		const dx = b.x - other.x;
		const dz = b.z - other.z;
		const d = Math.hypot(dx, dz);
		if (d > .01 && d < 1.25) {
			b.x += dx / d * (1.25 - d) * .5;
			b.z += dz / d * (1.25 - d) * .5;
		}
	}
	if (b.landed && !inZone(sim, b.x, b.z)) hurt(sim, b, zoneDamage(sim.stage) * dt, false);
}
function checkWin(sim) {
	if (!sim.player.alive || sim.phase === "over") return;
	if (aliveCount(sim) === 1) {
		sim.won = true;
		say(sim, "Último de pé", "ok", 4);
		notePlace(sim, 1);
	}
}
function step(sim, dt, input) {
	sim.time += dt;
	sim.shake = Math.max(0, sim.shake - dt * 1.6);
	if (sim.bannerT > 0) sim.bannerT = Math.max(0, sim.bannerT - dt);
	if (sim.events.length > 32) sim.events.splice(0, sim.events.length - 32);
	if (sim.phase !== "drop" && sim.phase !== "play") return;
	const p = sim.player;
	p.yaw -= input.lookDx * .0048;
	p.pitch = Math.max(-.42, Math.min(.6, p.pitch - input.lookDy * .0034));
	p.fireCd = Math.max(0, p.fireCd - dt);
	p.muroCd = Math.max(0, p.muroCd - dt);
	p.pulse = Math.max(0, p.pulse - dt);
	p.pulseCd = Math.max(0, p.pulseCd - dt);
	if (p.alive) {
		if (!p.landed) {
			const { fx, fz, rx, rz } = basis$1(p.yaw);
			const spd = 13;
			p.x += (rx * input.mx + fx * input.mz) * spd * dt;
			p.z += (rz * input.mx + fz * input.mz) * spd * dt;
			p.speed = spd * Math.hypot(input.mx, input.mz);
			p.y -= 9 * dt;
			pushSolids(sim, p);
			clampArena(p);
			if (p.y <= 0) {
				p.y = 0;
				p.landed = true;
				sim.phase = "play";
				say(sim, "No chão. Loot e zona.", "ok", 1.8);
			}
		} else {
			if (input.crouch) p.crouch = !p.crouch;
			if (input.swap && p.side) {
				const gun = p.gun;
				const mag = p.mag;
				const reserve = p.reserve;
				p.gun = p.side;
				p.mag = p.sideMag;
				p.reserve = p.sideReserve;
				p.side = gun;
				p.sideMag = mag;
				p.sideReserve = reserve;
				p.reload = 0;
				say(sim, GUN_LABEL[p.gun], "ok", .7);
			}
			if (input.pulse && p.pulseCd <= 0) {
				p.pulse = 4;
				p.pulseCd = 16;
				say(sim, "Pulso — inimigos no mapa", "ok", 1.2);
			}
			const moving = Math.hypot(input.mx, input.mz);
			if (p.channel > 0 && moving > .2) {
				p.channel = 0;
				say(sim, "Kit cancelado", "bad", .6);
			} else if (p.channel > 0) {
				p.channel -= dt;
				if (p.channel <= 0) {
					p.channel = 0;
					p.hp = Math.min(200, p.hp + 90);
					p.meds -= 1;
					say(sim, "Kit usado", "ok", .8);
				}
			} else if (input.med && p.meds > 0 && p.hp < 200) {
				p.channel = 1.15;
				say(sim, "Usando kit…", "ok", 1.15);
			}
			const { fx, fz, rx, rz } = basis$1(p.yaw);
			const run = moving > .82 && !p.crouch;
			const spd = p.crouch ? 4.3 : run ? 8.7 : 6.3;
			const vx = (rx * input.mx + fx * input.mz) * spd;
			const vz = (rz * input.mx + fz * input.mz) * spd;
			p.x += vx * dt;
			p.z += vz * dt;
			p.speed = Math.hypot(vx, vz);
			if (input.jump && p.y <= .05 && !p.crouch) p.vy = 6.3;
			p.vy -= 22 * dt;
			p.y += p.vy * dt;
			if (p.y <= 0) {
				p.y = 0;
				p.vy = 0;
			}
			pushSolids(sim, p);
			clampArena(p);
			if (p.reload > 0) {
				p.reload -= dt;
				if (p.reload <= 0) finishReload(p);
			}
			if (input.muro) placeMuro(sim, p);
			if (input.fire && p.channel <= 0) shoot(sim, p, p.crouch ? .01 : 0);
			pickupNear(sim, p);
		}
	}
	for (const b of sim.bots) stepBot(sim, b, dt);
	if (sim.phase === "play") {
		sim.playTime += dt;
		stepZone(sim, dt);
		if (p.alive && p.landed && !inZone(sim, p.x, p.z)) {
			hurt(sim, p, zoneDamage(sim.stage) * dt, false);
			if (p.alive && sim.bannerT <= 0) say(sim, "Fora da zona", "bad", .6);
		}
	}
	for (let i = sim.muros.length - 1; i >= 0; i--) if (sim.muros[i].hp <= 0) sim.muros.splice(i, 1);
	checkWin(sim);
}
var HALL = [
	{
		x: 8,
		z: 16,
		color: 4046476
	},
	{
		x: -16,
		z: 12,
		color: 14826299
	},
	{
		x: 18,
		z: -8,
		color: 3895266
	},
	{
		x: -6,
		z: -16,
		color: 15180346
	}
];
var NAV = /* @__PURE__ */ new Set([
	"Space",
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight"
]);
var LOOT_COLOR = {
	ar: 15180346,
	shotgun: 14826299,
	pistol: 12891546,
	vest: 4046476,
	med: 15985891,
	muro: 8377551,
	ammo: 13808778
};
function mount(canvas, wrap) {
	const renderer = new WebGLRenderer({
		canvas,
		antialias: true,
		alpha: false,
		powerPreference: "high-performance"
	});
	renderer.setClearColor(1708558);
	renderer.outputColorSpace = SRGBColorSpace;
	renderer.toneMapping = 0;
	const scene = new Scene();
	scene.fog = new FogExp2(1708558, .012);
	const camera = new PerspectiveCamera(58, 1, .1, 240);
	camera.position.set(0, 8, 14);
	camera.lookAt(0, 1, 0);
	scene.add(new HemisphereLight(16773597, 9060400, 1.25));
	const sun = new DirectionalLight(16773330, 2);
	sun.position.set(18, 28, 10);
	scene.add(sun);
	const fill = new DirectionalLight(10401496, .55);
	fill.position.set(-12, 10, -8);
	scene.add(fill);
	const floor = new Mesh(new CircleGeometry(90, 48), new MeshBasicMaterial({ color: 2758674 }));
	floor.rotation.x = -Math.PI / 2;
	floor.position.y = -.08;
	scene.add(floor);
	const ground = new Mesh(new CircleGeometry(48, 80), groundMaterial());
	ground.rotation.x = -Math.PI / 2;
	scene.add(ground);
	scene.add(makeStars());
	for (const planet of makePlanets()) scene.add(planet);
	scene.add(makeWreck());
	const poleGeo = new CylinderGeometry(.06, .08, 2.1, 6);
	const poleMat = new MeshStandardMaterial({
		color: 2760988,
		roughness: .75
	});
	const lampGeo = new SphereGeometry(.34, 12, 10);
	for (const hall of HALL) {
		const g = new Group();
		const post = new Mesh(poleGeo, poleMat);
		post.position.y = 1.05;
		const lamp = new Mesh(lampGeo, new MeshBasicMaterial({ color: hall.color }));
		lamp.position.y = 2.15;
		g.add(post, lamp);
		g.position.set(hall.x, 0, hall.z);
		scene.add(g);
	}
	const rockGeo = new IcosahedronGeometry(1, 0);
	const rockMat = new MeshStandardMaterial({
		color: 5911076,
		roughness: .92,
		flatShading: true
	});
	for (let i = 0; i < 10; i++) {
		const a = i / 10 * Math.PI * 2 + .3;
		const rock = new Mesh(rockGeo, rockMat);
		const s = .55 + i % 3 * .35;
		rock.scale.setScalar(s);
		rock.position.set(Math.cos(a) * 44.8, s * .3, Math.sin(a) * 44.8);
		scene.add(rock);
	}
	const coverMat = new MeshStandardMaterial({
		color: 6968132,
		roughness: .8
	});
	const coverGeo = new BoxGeometry(1, 1, 1);
	for (const cover of COVERS) {
		const mesh = new Mesh(coverGeo, coverMat);
		mesh.scale.set(cover.hx * 2, 1.3, cover.hz * 2);
		mesh.position.set(cover.x, .65, cover.z);
		mesh.rotation.y = cover.yaw;
		scene.add(mesh);
	}
	const zoneRing = new Mesh(new RingGeometry(.985, 1.02, 96), new MeshBasicMaterial({
		color: 4114112,
		side: 2
	}));
	zoneRing.rotation.x = -Math.PI / 2;
	zoneRing.position.y = .18;
	scene.add(zoneRing);
	const zoneWall = new Mesh(new CylinderGeometry(1, 1, 8, 72, 1, true), new MeshBasicMaterial({
		color: 1339e3,
		transparent: true,
		opacity: .22,
		side: 2,
		depthWrite: false
	}));
	zoneWall.position.y = 4;
	scene.add(zoneWall);
	const player = makeFighter(15180346, false);
	scene.add(player.group);
	const bots = /* @__PURE__ */ new Map();
	const loot = /* @__PURE__ */ new Map();
	const muros = /* @__PURE__ */ new Map();
	const lootGeo = new OctahedronGeometry(.38, 0);
	const muroGeo = new BoxGeometry(2.7, 1.7, .38);
	const muroMat = new MeshStandardMaterial({
		color: 12054505,
		emissive: 2787974,
		emissiveIntensity: .35,
		transparent: true,
		opacity: .88,
		roughness: .25
	});
	const tracers = makeTracers();
	scene.add(tracers.group);
	const desired = new Vector3();
	const look = new Vector3();
	const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	let epoch = runtime.sim.epoch;
	let last = performance.now();
	let raf = 0;
	let alive = true;
	const onKeyDown = (e) => {
		runtime.keys.add(e.code);
		if (runtime.sim.phase !== "boot" && NAV.has(e.code)) e.preventDefault();
	};
	const onKeyUp = (e) => runtime.keys.delete(e.code);
	const onBlur = () => {
		runtime.keys.clear();
		runtime.fireHeld = false;
	};
	window.addEventListener("keydown", onKeyDown);
	window.addEventListener("keyup", onKeyUp);
	window.addEventListener("blur", onBlur);
	window.__controlsTest = {
		getYaw: () => runtime.sim.player.yaw,
		getSpeed: () => runtime.sim.player.speed,
		getX: () => runtime.sim.player.x,
		getZ: () => runtime.sim.player.z,
		setKeys: (codes) => {
			runtime.keys = new Set(codes);
		}
	};
	const resize = () => {
		const w = wrap.clientWidth || 1;
		const h = wrap.clientHeight || 1;
		renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, w < 700 ? 1.5 : 1.75));
		renderer.setSize(w, h, false);
		camera.aspect = w / h;
		camera.updateProjectionMatrix();
	};
	resize();
	const observer = new ResizeObserver(resize);
	observer.observe(wrap);
	const frame = (now) => {
		if (!alive) return;
		raf = requestAnimationFrame(frame);
		const dt = Math.min(.05, (now - last) / 1e3);
		last = now;
		const sim = runtime.sim;
		if (sim.epoch !== epoch) {
			for (const mesh of bots.values()) mesh.group.removeFromParent();
			bots.clear();
			for (const mesh of loot.values()) mesh.removeFromParent();
			loot.clear();
			for (const mesh of muros.values()) mesh.removeFromParent();
			muros.clear();
			epoch = sim.epoch;
		}
		step(sim, dt, readInput());
		publish();
		const p = sim.player;
		poseFighter(player, p, sim.time);
		player.group.visible = p.alive;
		syncBots(scene, bots, sim.bots, sim.time);
		syncLoot(scene, loot, lootGeo, sim.loot, sim.time);
		syncMuros(scene, muros, muroGeo, muroMat, sim.muros);
		for (const ev of sim.events) {
			if (ev.type === "shot") tracers.spawn(ev);
			playEvent(ev.type);
		}
		sim.events.length = 0;
		tracers.tick(dt);
		zoneRing.position.set(sim.zoneX, .18, sim.zoneZ);
		zoneRing.scale.set(sim.zoneR, sim.zoneR, 1);
		zoneWall.position.set(sim.zoneX, 4, sim.zoneZ);
		zoneWall.scale.set(sim.zoneR, 1, sim.zoneR);
		const { fx, fz } = basis(p.yaw);
		const back = p.landed ? 5.1 : 11;
		const eye = (p.crouch ? 1.05 : 1.5) + p.y;
		const follow = 1 - Math.exp(-(reduced ? 16 : p.landed ? 7 : 2.2) * dt);
		if (sim.phase === "boot") {
			const ang = reduced ? .6 : sim.time * .15;
			desired.set(Math.sin(ang) * 18, 9, Math.cos(ang) * 18);
			look.set(0, 1, 0);
		} else {
			const cos = Math.cos(p.pitch);
			desired.set(p.x - fx * back * cos, eye + .45 + Math.sin(p.pitch) * back * .75, p.z - fz * back * cos);
			look.set(p.x + fx * 8, eye - .1 + Math.sin(p.pitch) * 6, p.z + fz * 8);
		}
		camera.position.lerp(desired, follow);
		if (sim.shake > 0 && !reduced) {
			camera.position.x += (Math.random() - .5) * sim.shake;
			camera.position.y += (Math.random() - .5) * sim.shake * .4;
		}
		camera.lookAt(look);
		renderer.render(scene, camera);
	};
	raf = requestAnimationFrame(frame);
	return () => {
		alive = false;
		cancelAnimationFrame(raf);
		observer.disconnect();
		window.removeEventListener("keydown", onKeyDown);
		window.removeEventListener("keyup", onKeyUp);
		window.removeEventListener("blur", onBlur);
		if (window.__controlsTest) delete window.__controlsTest;
		renderer.dispose();
		scene.traverse((node) => {
			const mesh = node;
			if (mesh.geometry) mesh.geometry.dispose();
			const mat = mesh.material;
			if (!mat) return;
			if (Array.isArray(mat)) for (const m of mat) m.dispose();
			else mat.dispose();
		});
	};
}
function basis(yaw) {
	return {
		fx: -Math.sin(yaw),
		fz: -Math.cos(yaw)
	};
}
function makeFighter(accent, dark) {
	const group = new Group();
	const cloth = new MeshStandardMaterial({
		color: dark ? 4862e3 : 9263668,
		roughness: .62
	});
	const skin = new MeshStandardMaterial({
		color: 12880482,
		roughness: .55
	});
	const metal = new MeshStandardMaterial({
		color: 2366486,
		metalness: .45,
		roughness: .4
	});
	const band = new MeshStandardMaterial({
		color: accent,
		emissive: accent,
		emissiveIntensity: .45,
		roughness: .4
	});
	const torso = new Mesh(new BoxGeometry(.48, .55, .26), cloth);
	torso.position.y = 1.08;
	const head = new Mesh(new BoxGeometry(.28, .28, .28), skin);
	head.position.y = 1.52;
	const hips = new Mesh(new BoxGeometry(.42, .14, .24), band);
	hips.position.y = .74;
	const legL = new Mesh(new BoxGeometry(.14, .52, .16), cloth);
	legL.position.set(-.12, .36, 0);
	const legR = new Mesh(new BoxGeometry(.14, .52, .16), cloth);
	legR.position.set(.12, .36, 0);
	const gun = new Mesh(new BoxGeometry(.1, .1, .72), metal);
	gun.position.set(.22, 1.05, .42);
	group.add(torso, head, hips, legL, legR, gun);
	return {
		group,
		legL,
		legR,
		hips
	};
}
function poseFighter(view, f, time) {
	const bob = f.landed ? Math.sin(time * (f.speed > 4 ? 12 : 2)) * Math.min(.08, f.speed * .01) : 0;
	view.group.position.set(f.x, f.y + (f.crouch ? -.32 : 0) + bob, f.z);
	view.group.rotation.y = f.yaw + Math.PI;
	view.group.visible = f.alive;
	const swing = Math.sin(time * 11) * Math.min(.7, f.speed / 7);
	view.legL.rotation.x = swing;
	view.legR.rotation.x = -swing;
	view.hips.material.emissive.setHex(f.armor > 0 ? 4046476 : 15180346);
}
function syncBots(scene, map, list, time) {
	const alive = new Set(list.filter((b) => b.alive).map((b) => b.id));
	for (const [id, view] of map) {
		if (alive.has(id)) continue;
		view.group.removeFromParent();
		map.delete(id);
	}
	for (const bot of list) {
		if (!bot.alive) continue;
		let view = map.get(bot.id);
		if (!view) {
			view = makeFighter(13914938, true);
			scene.add(view.group);
			map.set(bot.id, view);
		}
		poseFighter(view, bot, time + bot.id);
	}
}
function syncLoot(scene, map, geo, list, time) {
	const alive = new Set(list.map((item) => item.id));
	for (const [id, mesh] of map) {
		if (alive.has(id)) continue;
		mesh.removeFromParent();
		map.delete(id);
	}
	for (const item of list) {
		let mesh = map.get(item.id);
		if (!mesh) {
			mesh = new Mesh(geo, new MeshBasicMaterial({ color: LOOT_COLOR[item.kind] }));
			scene.add(mesh);
			map.set(item.id, mesh);
		}
		mesh.position.set(item.x, .55 + Math.sin(time * 2.4 + item.id) * .08, item.z);
		mesh.rotation.y = time * .8;
	}
}
function syncMuros(scene, map, geo, mat, list) {
	const alive = new Set(list.map((m) => m.id));
	for (const [id, mesh] of map) {
		if (alive.has(id)) continue;
		mesh.removeFromParent();
		map.delete(id);
	}
	for (const muro of list) {
		let mesh = map.get(muro.id);
		if (!mesh) {
			mesh = new Mesh(geo, mat);
			scene.add(mesh);
			map.set(muro.id, mesh);
		}
		mesh.position.set(muro.x, .85, muro.z);
		mesh.rotation.y = muro.yaw;
		mesh.scale.y = Math.max(.35, muro.hp / 220);
	}
}
function makeTracers() {
	const group = new Group();
	const geo = new BoxGeometry(.045, .045, 1);
	const mat = new MeshBasicMaterial({ color: 16769955 });
	const pool = Array.from({ length: 28 }, () => {
		const mesh = new Mesh(geo, mat);
		mesh.visible = false;
		mesh.userData.life = 0;
		group.add(mesh);
		return mesh;
	});
	return {
		group,
		spawn(ev) {
			const mesh = pool.find((item) => item.userData.life <= 0);
			if (!mesh) return;
			const dx = ev.x2 - ev.x;
			const dz = ev.z2 - ev.z;
			const len = Math.hypot(dx, dz) || .001;
			mesh.visible = true;
			mesh.userData.life = .07;
			mesh.scale.z = len;
			mesh.position.set((ev.x + ev.x2) / 2, 1.15, (ev.z + ev.z2) / 2);
			mesh.lookAt(ev.x2, 1.15, ev.z2);
		},
		tick(dt) {
			for (const mesh of pool) {
				if (mesh.userData.life <= 0) continue;
				mesh.userData.life -= dt;
				if (mesh.userData.life <= 0) mesh.visible = false;
			}
		}
	};
}
function groundMaterial() {
	return new ShaderMaterial({
		vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
		fragmentShader: `
      precision mediump float;
      varying vec2 vUv;
      void main() {
        vec2 p = vUv * 2.0 - 1.0;
        float r = length(p);
        float rings = smoothstep(0.02, 0.0, abs(fract(r * 10.0) - 0.12));
        vec3 lo = vec3(0.55, 0.24, 0.12);
        vec3 hi = vec3(0.82, 0.42, 0.2);
        vec3 col = mix(lo, hi, r);
        col = mix(col, col * 0.75, rings);
        float rim = smoothstep(0.9, 1.0, r);
        col = mix(col, vec3(0.95, 0.68, 0.26), rim);
        gl_FragColor = vec4(col, 1.0);
      }
    `
	});
}
function makeStars() {
	const n = 500;
	const pos = new Float32Array(n * 3);
	for (let i = 0; i < n; i++) {
		const r = 80 + Math.random() * 30;
		const th = Math.random() * Math.PI * 2;
		const ph = Math.acos(2 * Math.random() - 1);
		pos[i * 3] = r * Math.sin(ph) * Math.cos(th);
		pos[i * 3 + 1] = Math.abs(r * Math.cos(ph));
		pos[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
	}
	const geo = new BufferGeometry();
	geo.setAttribute("position", new BufferAttribute(pos, 3));
	return new Points(geo, new PointsMaterial({
		color: 16774888,
		size: 1.2,
		sizeAttenuation: true,
		fog: false
	}));
}
function makePlanets() {
	const geo = new IcosahedronGeometry(1, 1);
	return [
		{
			p: [
				-40,
				16,
				-48
			],
			s: 8,
			c: 12870216,
			e: 6957080
		},
		{
			p: [
				48,
				12,
				-36
			],
			s: 5,
			c: 10137536,
			e: 3359824
		},
		{
			p: [
				-28,
				22,
				46
			],
			s: 3.4,
			c: 15127216,
			e: 6969408
		}
	].map((spec) => {
		const mesh = new Mesh(geo, new MeshStandardMaterial({
			color: spec.c,
			emissive: spec.e,
			emissiveIntensity: .7,
			flatShading: true,
			roughness: .8
		}));
		mesh.position.set(spec.p[0], spec.p[1], spec.p[2]);
		mesh.scale.setScalar(spec.s);
		return mesh;
	});
}
function makeWreck() {
	const g = new Group();
	const mat = new MeshStandardMaterial({
		color: 12036764,
		metalness: .4,
		roughness: .4
	});
	const hull = new Mesh(new BoxGeometry(1.3, .38, 3.4), mat);
	hull.position.y = .32;
	const fin = new Mesh(new BoxGeometry(2.3, .08, .55), mat);
	fin.position.set(0, .5, -1.15);
	g.add(hull, fin);
	g.position.set(14, 0, -6);
	g.rotation.set(.15, .7, .42);
	return g;
}
function SigmaField() {
	const wrapRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	const [glError, setGlError] = (0, import_react.useState)(null);
	const hud = (0, import_react.useSyncExternalStore)(subscribe, getHud, getServerHud);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return;
		try {
			return mount(canvas, wrap);
		} catch (error) {
			setGlError(error instanceof Error ? error.message : "Sem WebGL");
		}
	}, []);
	const live = hud.phase === "drop" || hud.phase === "play";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: "field absolute inset-0",
		onPointerDown: () => unlockAudio(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "block h-full w-full"
			}),
			hud.outside ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "storm-vignette pointer-events-none absolute inset-0 z-10" }) : null,
			live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayHud, { hud }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimap, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LookZone, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveStick, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Actions, { hud })
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
				hud,
				glError
			})
		]
	});
}
function Crosshair() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute top-1/2 left-1/2 z-10 h-5 w-5 -translate-x-1/2 -translate-y-1/2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1/2 left-0 h-px w-2 -translate-y-1/2 bg-fg" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1/2 right-0 h-px w-2 -translate-y-1/2 bg-fg" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0 left-1/2 h-2 w-px -translate-x-1/2 bg-fg" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-0 left-1/2 h-2 w-px -translate-x-1/2 bg-fg" })
		]
	});
}
function PlayHud({ hud }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "hud-top pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-3 px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-28" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-xs tracking-widest text-muted uppercase",
						children: [
							hud.alive,
							"/",
							hud.total,
							" vivos"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: `font-mono text-sm ${hud.shrinking || hud.outside ? "text-danger" : "text-fg"}`,
						children: [hud.shrinking ? "zona fechando" : `zona ${hud.zoneIn}s`, hud.outside ? " · fora" : ""]
					}),
					hud.banner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `mt-1 font-mono text-sm ${hud.tone === "bad" ? "text-danger" : "text-primary"}`,
						children: hud.banner
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-mono text-xs text-fg",
						children: [
							GUN_LABEL[hud.gun],
							" ",
							hud.reloading ? "recarrega" : `${hud.mag}/${hud.reserve}`
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-2 h-2 w-28 bg-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-danger",
							style: { width: `${Math.min(100, hud.hp / 200 * 100)}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto mt-1 h-1.5 w-28 bg-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-signal-physics",
							style: { width: `${Math.min(100, hud.armor)}%` }
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-28 text-right",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs text-muted uppercase",
					children: "abates"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xl leading-none text-fg",
					children: hud.kills
				})]
			})
		]
	});
}
function Minimap() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		const draw = () => {
			raf = requestAnimationFrame(draw);
			const sim = runtime.sim;
			const w = canvas.width;
			const scale = w * .46 / 46;
			const cx = w / 2;
			const cy = w / 2;
			ctx.clearRect(0, 0, w, w);
			ctx.fillStyle = "#1c1612";
			ctx.beginPath();
			ctx.arc(cx, cy, w / 2 - 1, 0, Math.PI * 2);
			ctx.fill();
			ctx.strokeStyle = "#3ec6c0";
			ctx.lineWidth = 2;
			ctx.beginPath();
			ctx.arc(cx + sim.zoneX * scale, cy + sim.zoneZ * scale, Math.max(2, sim.zoneR * scale), 0, Math.PI * 2);
			ctx.stroke();
			for (const bot of sim.bots) {
				if (!bot.alive || !bot.landed) continue;
				if (Math.hypot(bot.x - sim.player.x, bot.z - sim.player.z) > 24 && sim.player.pulse <= 0) continue;
				ctx.fillStyle = "#d4533a";
				ctx.fillRect(cx + bot.x * scale - 1.5, cy + bot.z * scale - 1.5, 3, 3);
			}
			const px = cx + sim.player.x * scale;
			const py = cy + sim.player.z * scale;
			ctx.save();
			ctx.translate(px, py);
			ctx.rotate(-sim.player.yaw);
			ctx.fillStyle = "#e7a23a";
			ctx.beginPath();
			ctx.moveTo(0, -6);
			ctx.lineTo(4, 5);
			ctx.lineTo(-4, 5);
			ctx.fill();
			ctx.restore();
		};
		raf = requestAnimationFrame(draw);
		return () => cancelAnimationFrame(raf);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		width: 112,
		height: 112,
		className: "pointer-events-none absolute top-4 left-4 z-20 h-28 w-28 rounded-full border border-line"
	});
}
function LookZone() {
	const last = (0, import_react.useRef)({
		x: 0,
		y: 0,
		on: false
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-y-0 right-0 z-10 w-1/2 touch-none",
		onPointerDown: (e) => {
			if (e.target.closest("button")) return;
			e.currentTarget.setPointerCapture(e.pointerId);
			last.current = {
				x: e.clientX,
				y: e.clientY,
				on: true
			};
		},
		onPointerMove: (e) => {
			if (!last.current.on) return;
			runtime.lookDx += e.clientX - last.current.x;
			runtime.lookDy += e.clientY - last.current.y;
			last.current.x = e.clientX;
			last.current.y = e.clientY;
		},
		onPointerUp: () => {
			last.current.on = false;
		},
		onPointerCancel: () => {
			last.current.on = false;
		}
	});
}
function MoveStick() {
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const origin = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const release = () => {
		setKnob({
			x: 0,
			y: 0
		});
		runtime.stick.x = 0;
		runtime.stick.y = 0;
		runtime.stick.active = false;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "stick-anchor absolute z-20 flex h-40 w-40 touch-none items-center justify-center",
		role: "application",
		"aria-label": "Mover",
		onPointerDown: (e) => {
			e.stopPropagation();
			e.currentTarget.setPointerCapture(e.pointerId);
			origin.current = {
				x: e.clientX,
				y: e.clientY
			};
			unlockAudio();
		},
		onPointerMove: (e) => {
			if (!e.currentTarget.hasPointerCapture(e.pointerId)) return;
			const dx = e.clientX - origin.current.x;
			const dy = e.clientY - origin.current.y;
			const max = 48;
			const mag = Math.hypot(dx, dy) || 1;
			const nx = dx / mag * Math.min(max, mag);
			const ny = dy / mag * Math.min(max, mag);
			setKnob({
				x: nx,
				y: ny
			});
			runtime.stick.x = nx / max;
			runtime.stick.y = -ny / max;
			runtime.stick.active = true;
		},
		onPointerUp: release,
		onPointerCancel: release,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative h-28 w-28 rounded-full border border-line bg-bg/60",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute top-1/2 left-1/2 h-12 w-12 rounded-full bg-primary",
				style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
			})
		})
	});
}
function Actions({ hud }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "boost-anchor absolute z-20 flex flex-col items-end gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Act, {
					label: "Pulo",
					onTap: () => tap("jump")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Act, {
					label: hud.meds > 0 ? `Kit ${hud.meds}` : "Kit",
					disabled: hud.meds <= 0,
					onTap: () => tap("med")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Act, {
					label: hud.muros > 0 ? `Muro ${hud.muros}` : "Muro",
					disabled: hud.muros <= 0,
					onTap: () => tap("muro")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Act, {
					label: hud.crouch ? "Baixo" : "Baixa",
					onTap: () => tap("crouch")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Act, {
					label: "Troca",
					onTap: () => tap("swap")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Act, {
					label: hud.pulseReady ? "Pulso" : "···",
					disabled: !hud.pulseReady,
					onTap: () => tap("pulse")
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "flex h-20 w-20 items-center justify-center rounded-full border border-primary bg-primary font-mono text-sm text-bg",
			"aria-label": "Atirar",
			onPointerDown: (e) => {
				e.stopPropagation();
				e.currentTarget.setPointerCapture(e.pointerId);
				runtime.fireHeld = true;
				unlockAudio();
			},
			onPointerUp: () => {
				runtime.fireHeld = false;
			},
			onPointerCancel: () => {
				runtime.fireHeld = false;
			},
			children: hud.landed ? "Atirar" : "···"
		})]
	});
}
function Act({ label, onTap, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		disabled,
		className: "flex h-12 w-12 items-center justify-center rounded-full border border-line bg-surface/90 font-mono text-xs leading-none text-fg disabled:text-muted",
		onPointerDown: (e) => {
			e.stopPropagation();
			if (!disabled) onTap();
		},
		children: label
	});
}
function Menu({ hud, glError }) {
	const over = hud.phase === "over";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-30 flex flex-col justify-end p-4 md:justify-center md:p-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rise pointer-events-auto max-h-full w-full max-w-md overflow-auto rounded-card border border-line bg-surface/95 p-5 backdrop-blur-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-widest text-muted uppercase",
					children: over ? hud.place === 1 ? "último de pé" : "queda encerrada" : "queda · 11 no disco"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-2 flex items-baseline gap-3 leading-none",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-5xl text-primary",
						children: "Σ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-4xl",
						children: over ? `#${hud.place}` : "Sigma"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-lg leading-snug text-fg",
					children: over ? hud.place === 1 ? "Você fechou a zona sozinho." : `${hud.kills} abates nessa queda.` : "Cai, pega arma, levanta muro e segura a zona até sobrar um."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-mono text-xs leading-relaxed text-muted",
					children: "Esquerda move. Arraste a direita para olhar. A vai para a esquerda da tela. Atirar, muro, kit e pulo ficam na direita."
				}),
				glError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-mono text-xs text-danger",
					children: glError
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-5 h-12 w-full rounded-card bg-primary font-mono text-sm text-bg",
					onClick: () => {
						unlockAudio();
						begin();
					},
					children: over ? "Pular de novo" : "Pular"
				}),
				hud.best > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 font-mono text-xs text-muted",
					children: ["melhor colocação #", hud.best]
				}) : null
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SigmaField, {})
	});
}
//#endregion
export { Home as component };
