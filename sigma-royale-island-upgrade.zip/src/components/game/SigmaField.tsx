import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { mount } from "@/game/mount";
import { unlockAudio } from "@/game/audio";
import {
  ARENA,
  begin,
  getHud,
  getServerHud,
  GUN_LABEL,
  runtime,
  subscribe,
  tap,
  type HudSnap,
} from "@/game/sim";

export function SigmaField() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [glError, setGlError] = useState<string | null>(null);
  const hud = useSyncExternalStore(subscribe, getHud, getServerHud);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    try {
      return mount(canvas, wrap);
    } catch (error) {
      setGlError(error instanceof Error ? error.message : "Sem WebGL");
    }
  }, []);

  const live = hud.phase === "drop" || hud.phase === "play";

  return (
    <div ref={wrapRef} className="field absolute inset-0" onPointerDown={() => unlockAudio()}>
      <canvas ref={canvasRef} className="block h-full w-full" />
      {hud.outside ? <div className="storm-vignette pointer-events-none absolute inset-0 z-10" /> : null}
      {live ? (
        <>
          <Crosshair />
          <PlayHud hud={hud} />
          <Minimap />
          <LookZone />
          <MoveStick />
          <Actions hud={hud} />
        </>
      ) : (
        <Menu hud={hud} glError={glError} />
      )}
    </div>
  );
}

function Crosshair() {
  return (
    <div className="pointer-events-none absolute top-1/2 left-1/2 z-10 h-5 w-5 -translate-x-1/2 -translate-y-1/2">
      <span className="absolute top-1/2 left-0 h-px w-2 -translate-y-1/2 bg-fg" />
      <span className="absolute top-1/2 right-0 h-px w-2 -translate-y-1/2 bg-fg" />
      <span className="absolute top-0 left-1/2 h-2 w-px -translate-x-1/2 bg-fg" />
      <span className="absolute bottom-0 left-1/2 h-2 w-px -translate-x-1/2 bg-fg" />
    </div>
  );
}

function PlayHud({ hud }: { hud: HudSnap }) {
  return (
    <header className="hud-top pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-3 px-4">
      <div className="w-28" />
      <div className="min-w-0 text-center">
        <p className="font-mono text-xs tracking-widest text-muted uppercase">
          {hud.alive}/{hud.total} vivos
        </p>
        <p className={`font-mono text-sm ${hud.shrinking || hud.outside ? "text-danger" : "text-fg"}`}>
          {hud.shrinking ? "zona fechando" : `zona ${hud.zoneIn}s`}
          {hud.outside ? " · fora" : ""}
        </p>
        {hud.banner ? (
          <p className={`mt-1 font-mono text-sm ${hud.tone === "bad" ? "text-danger" : "text-primary"}`}>{hud.banner}</p>
        ) : null}
        <p className="mt-1 font-mono text-xs text-fg">
          {GUN_LABEL[hud.gun]} {hud.reloading ? "recarrega" : `${hud.mag}/${hud.reserve}`}
        </p>
        <div className="mx-auto mt-2 h-2 w-28 bg-line">
          <div className="h-full bg-danger" style={{ width: `${Math.min(100, (hud.hp / 200) * 100)}%` }} />
        </div>
        <div className="mx-auto mt-1 h-1.5 w-28 bg-line">
          <div className="h-full bg-signal-physics" style={{ width: `${Math.min(100, hud.armor)}%` }} />
        </div>
      </div>
      <div className="w-28 text-right">
        <p className="font-mono text-xs text-muted uppercase">abates</p>
        <p className="font-mono text-2xl leading-none text-fg">{hud.kills}</p>
      </div>
    </header>
  );
}

function Minimap() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      const sim = runtime.sim;
      const w = canvas.width;
      const scale = (w * 0.46) / ARENA;
      const cx = w / 2;
      const cy = w / 2;
      ctx.clearRect(0, 0, w, w);
      ctx.fillStyle = "#1c1612";
      ctx.beginPath();
      ctx.arc(cx, cy, w / 2 - 1, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#3ec6c0";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx + sim.zoneX * scale, cy + sim.zoneZ * scale, Math.max(2, sim.zoneR * scale), 0, Math.PI * 2);
      ctx.stroke();
      for (const bot of sim.bots) {
        if (!bot.alive || !bot.landed) continue;
        const d = Math.hypot(bot.x - sim.player.x, bot.z - sim.player.z);
        if (d > 24 && sim.player.pulse <= 0) continue;
        ctx.fillStyle = "#d4533a";
        ctx.fillRect(cx + bot.x * scale - 1.5, cy + bot.z * scale - 1.5, 3, 3);
      }
      const px = cx + sim.player.x * scale;
      const py = cy + sim.player.z * scale;
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(-sim.player.yaw);
      ctx.fillStyle = "#e7a23a";
      ctx.beginPath();
      ctx.moveTo(0, -6);
      ctx.lineTo(4, 5);
      ctx.lineTo(-4, 5);
      ctx.fill();
      ctx.restore();
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);
  return (
    <canvas
      ref={ref}
      width={112}
      height={112}
      className="pointer-events-none absolute top-4 left-4 z-20 h-28 w-28 rounded-full border border-line"
    />
  );
}

function LookZone() {
  const last = useRef({ x: 0, y: 0, on: false });
  return (
    <div
      className="absolute inset-y-0 right-0 z-10 w-1/2 touch-none"
      onPointerDown={(e) => {
        if ((e.target as HTMLElement).closest("button")) return;
        e.currentTarget.setPointerCapture(e.pointerId);
        last.current = { x: e.clientX, y: e.clientY, on: true };
      }}
      onPointerMove={(e) => {
        if (!last.current.on) return;
        runtime.lookDx += e.clientX - last.current.x;
        runtime.lookDy += e.clientY - last.current.y;
        last.current.x = e.clientX;
        last.current.y = e.clientY;
      }}
      onPointerUp={() => {
        last.current.on = false;
      }}
      onPointerCancel={() => {
        last.current.on = false;
      }}
    />
  );
}

function MoveStick() {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const origin = useRef({ x: 0, y: 0 });
  const release = () => {
    setKnob({ x: 0, y: 0 });
    runtime.stick.x = 0;
    runtime.stick.y = 0;
    runtime.stick.active = false;
  };
  return (
    <div
      className="stick-anchor absolute z-20 flex h-40 w-40 touch-none items-center justify-center"
      role="application"
      aria-label="Mover"
      onPointerDown={(e) => {
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        origin.current = { x: e.clientX, y: e.clientY };
        unlockAudio();
      }}
      onPointerMove={(e) => {
        if (!e.currentTarget.hasPointerCapture(e.pointerId)) return;
        const dx = e.clientX - origin.current.x;
        const dy = e.clientY - origin.current.y;
        const max = 48;
        const mag = Math.hypot(dx, dy) || 1;
        const nx = (dx / mag) * Math.min(max, mag);
        const ny = (dy / mag) * Math.min(max, mag);
        setKnob({ x: nx, y: ny });
        runtime.stick.x = nx / max;
        runtime.stick.y = -ny / max;
        runtime.stick.active = true;
      }}
      onPointerUp={release}
      onPointerCancel={release}
    >
      <div className="relative h-28 w-28 rounded-full border border-line bg-bg/60">
        <div
          className="absolute top-1/2 left-1/2 h-12 w-12 rounded-full bg-primary"
          style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
        />
      </div>
    </div>
  );
}

function Actions({ hud }: { hud: HudSnap }) {
  return (
    <div className="boost-anchor absolute z-20 flex flex-col items-end gap-2">
      <div className="grid grid-cols-2 gap-2">
          <Act label="Pulo" onTap={() => tap("jump")} />
          <Act label={hud.meds > 0 ? `Kit ${hud.meds}` : "Kit"} disabled={hud.meds <= 0} onTap={() => tap("med")} />
          <Act label={hud.muros > 0 ? `Muro ${hud.muros}` : "Muro"} disabled={hud.muros <= 0} onTap={() => tap("muro")} />
          <Act label={hud.crouch ? "Baixo" : "Baixa"} onTap={() => tap("crouch")} />
          <Act label="Troca" onTap={() => tap("swap")} />
          <Act label={hud.pulseReady ? "Pulso" : "···"} disabled={!hud.pulseReady} onTap={() => tap("pulse")} />
      </div>
      <button
        type="button"
        className="flex h-20 w-20 items-center justify-center rounded-full border border-primary bg-primary font-mono text-sm text-bg"
        aria-label="Atirar"
        onPointerDown={(e) => {
          e.stopPropagation();
          e.currentTarget.setPointerCapture(e.pointerId);
          runtime.fireHeld = true;
          unlockAudio();
        }}
        onPointerUp={() => {
          runtime.fireHeld = false;
        }}
        onPointerCancel={() => {
          runtime.fireHeld = false;
        }}
      >
        {hud.landed ? "Atirar" : "···"}
      </button>
    </div>
  );
}

function Act({ label, onTap, disabled }: { label: string; onTap: () => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      disabled={disabled}
      className="flex h-12 w-12 items-center justify-center rounded-full border border-line bg-surface/90 font-mono text-xs leading-none text-fg disabled:text-muted"
      onPointerDown={(e) => {
        e.stopPropagation();
        if (!disabled) onTap();
      }}
    >
      {label}
    </button>
  );
}

function Menu({ hud, glError }: { hud: HudSnap; glError: string | null }) {
  const over = hud.phase === "over";
  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-end p-4 md:justify-center md:p-10">
      <section className="rise pointer-events-auto max-h-full w-full max-w-md overflow-auto rounded-card border border-line bg-surface/95 p-5 backdrop-blur-md">
        <p className="font-mono text-xs tracking-widest text-muted uppercase">
          {over ? (hud.place === 1 ? "último de pé" : "queda encerrada") : "queda · 11 no disco"}
        </p>
        <h1 className="mt-2 flex items-baseline gap-3 leading-none">
          <span className="text-5xl text-primary">Σ</span>
          <span className="text-4xl">{over ? `#${hud.place}` : "Sigma"}</span>
        </h1>
        <p className="mt-4 text-lg leading-snug text-fg">
          {over
            ? hud.place === 1
              ? "Você fechou a zona sozinho."
              : `${hud.kills} abates nessa queda.`
            : "Cai, pega arma, levanta muro e segura a zona até sobrar um."}
        </p>
        <p className="mt-3 font-mono text-xs leading-relaxed text-muted">
          Esquerda move. Arraste a direita para olhar. A vai para a esquerda da tela. Atirar, muro, kit e pulo ficam na direita.
        </p>
        {glError ? <p className="mt-3 font-mono text-xs text-danger">{glError}</p> : null}
        <button
          type="button"
          className="mt-5 h-12 w-full rounded-card bg-primary font-mono text-sm text-bg"
          onClick={() => {
            unlockAudio();
            begin();
          }}
        >
          {over ? "Pular de novo" : "Pular"}
        </button>
        {hud.best > 0 ? (
          <p className="mt-3 font-mono text-xs text-muted">melhor colocação #{hud.best}</p>
        ) : null}
      </section>
    </div>
  );
}
