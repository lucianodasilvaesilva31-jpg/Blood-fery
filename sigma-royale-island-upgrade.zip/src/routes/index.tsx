import { createFileRoute } from "@tanstack/react-router";
import { SigmaField } from "@/components/game/SigmaField";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <SigmaField />
    </main>
  );
}
