export type Phase = "boot" | "drop" | "play" | "over";
export type Gun = "pistol" | "ar" | "shotgun";
export type LootKind = Gun | "vest" | "med" | "muro" | "ammo";

export type Fighter = {
  id: number;
  x: number;
  z: number;
  y: number;
  vy: number;
  yaw: number;
  pitch: number;
  hp: number;
  armor: number;
  alive: boolean;
  landed: boolean;
  landX: number;
  landZ: number;
  gun: Gun;
  mag: number;
  reserve: number;
  reload: number;
  fireCd: number;
  meds: number;
  muros: number;
  muroCd: number;
  crouch: boolean;
  channel: number;
  pulse: number;
  pulseCd: number;
  speed: number;
  glooCd: number;
  side: Gun | null;
  sideMag: number;
  sideReserve: number;
};

export type Muro = { id: number; x: number; z: number; yaw: number; hp: number };
export type Loot = { id: number; kind: LootKind; x: number; z: number };
export type Cover = { x: number; z: number; yaw: number; hx: number; hz: number };

export type FxEvent = {
  type: "shot" | "hit" | "kill" | "pickup" | "muro";
  x: number;
  z: number;
  x2: number;
  z2: number;
};

export type Input = {
  mx: number;
  mz: number;
  lookDx: number;
  lookDy: number;
  fire: boolean;
  jump: boolean;
  muro: boolean;
  med: boolean;
  swap: boolean;
  crouch: boolean;
  pulse: boolean;
};

export type HudSnap = {
  phase: Phase;
  hp: number;
  armor: number;
  alive: number;
  total: number;
  kills: number;
  place: number;
  best: number;
  gun: Gun;
  mag: number;
  reserve: number;
  reloading: boolean;
  meds: number;
  muros: number;
  crouch: boolean;
  channel: boolean;
  outside: boolean;
  shrinking: boolean;
  zoneIn: number;
  banner: string;
  tone: "ok" | "bad";
  playTime: number;
  pulseReady: boolean;
  landed: boolean;
};

export const ARENA = 46;
export const BEST_KEY = "sigma-royale-best";
export const TOTAL = 11;

export const COVERS: Cover[] = [
  { x: 14, z: -6, yaw: 0.7, hx: 1.8, hz: 0.9 },
  { x: -9, z: 7, yaw: 0.3, hx: 1.4, hz: 1.3 },
  { x: 7, z: 14, yaw: 1.1, hx: 1.5, hz: 0.8 },
  { x: -14, z: -10, yaw: 0.2, hx: 1.2, hz: 1.2 },
];

const GUNS: Record<Gun, { dmg: number; rate: number; mag: number; reload: number; spread: number; pellets: number; range: number }> = {
  pistol: { dmg: 28, rate: 0.26, mag: 12, reload: 1.15, spread: 0.045, pellets: 1, range: 28 },
  ar: { dmg: 19, rate: 0.1, mag: 30, reload: 1.4, spread: 0.02, pellets: 1, range: 36 },
  shotgun: { dmg: 15, rate: 0.7, mag: 5, reload: 1.85, spread: 0.16, pellets: 6, range: 13 },
};

const ZONE_RADII = [40, 28, 18, 11, 6];

export const GUN_LABEL: Record<Gun, string> = {
  pistol: "Pistola",
  ar: "Fuzil",
  shotgun: "Escopeta",
};

type Bot = Fighter;

export type Sim = {
  epoch: number;
  phase: Phase;
  time: number;
  playTime: number;
  player: Fighter;
  bots: Bot[];
  muros: Muro[];
  loot: Loot[];
  zoneX: number;
  zoneZ: number;
  zoneR: number;
  zoneTx: number;
  zoneTz: number;
  zoneTr: number;
  zoneT: number;
  shrinking: boolean;
  stage: number;
  nextId: number;
  kills: number;
  place: number;
  best: number;
  won: boolean;
  shake: number;
  banner: string;
  bannerT: number;
  tone: "ok" | "bad";
  events: FxEvent[];
};

const SERVER_HUD: HudSnap = {
  phase: "boot",
  hp: 200,
  armor: 0,
  alive: TOTAL,
  total: TOTAL,
  kills: 0,
  place: 0,
  best: 0,
  gun: "pistol",
  mag: 12,
  reserve: 36,
  reloading: false,
  meds: 0,
  muros: 0,
  crouch: false,
  channel: false,
  outside: false,
  shrinking: false,
  zoneIn: 16,
  banner: "",
  tone: "ok",
  playTime: 0,
  pulseReady: true,
  landed: false,
};

function loadBest() {
  if (typeof window === "undefined") return 0;
  try {
    const n = Number(localStorage.getItem(BEST_KEY) || "0");
    return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
  } catch {
    return 0;
  }
}

function saveBest(n: number) {
  try {
    localStorage.setItem(BEST_KEY, String(n));
  } catch {
    /* ignore */
  }
}

function fighter(id: number, x: number, z: number, y: number): Fighter {
  return {
    id,
    x,
    z,
    y,
    vy: 0,
    yaw: 0,
    pitch: 0,
    hp: 200,
    armor: 0,
    alive: true,
    landed: false,
    landX: x,
    landZ: z,
    gun: "pistol",
    mag: 12,
    reserve: 48,
    reload: 0,
    fireCd: 0,
    meds: 0,
    muros: 0,
    muroCd: 0,
    crouch: false,
    channel: 0,
    pulse: 0,
    pulseCd: 0,
    speed: 0,
    glooCd: 0,
    side: null,
    sideMag: 0,
    sideReserve: 0,
  };
}

function ringPoint(i: number, n: number, minR: number, maxR: number) {
  const a = (i / n) * Math.PI * 2 + Math.random() * 0.35;
  const r = minR + Math.random() * (maxR - minR);
  return { x: Math.cos(a) * r, z: Math.sin(a) * r };
}

export function createSim(best = loadBest()): Sim {
  let nextId = 1;
  const drop = ringPoint(0, 1, 12, 22);
  const player = fighter(nextId++, drop.x, drop.z, 32);
  player.reserve = 36;
  player.yaw = Math.atan2(drop.x, drop.z);
  const bots: Bot[] = [];
  for (let i = 0; i < TOTAL - 1; i++) {
    const p = ringPoint(i, TOTAL - 1, 10, 30);
    const b = fighter(nextId++, p.x, p.z, 26 + Math.random() * 10);
    b.hp = 160;
    if (i % 3 === 0) {
      b.gun = "ar";
      b.mag = 30;
      b.reserve = 60;
    }
    b.muros = 1;
    bots.push(b);
  }
  const loot: Loot[] = [];
  const kinds: LootKind[] = ["ar", "ar", "shotgun", "shotgun", "vest", "vest", "vest", "med", "med", "med", "muro", "muro", "ammo", "ammo", "ammo"];
  for (const kind of kinds) {
    const p = ringPoint(loot.length, kinds.length, 4, 34);
    loot.push({ id: nextId++, kind, x: p.x, z: p.z });
  }
  return {
    epoch: 1,
    phase: "boot",
    time: 0,
    playTime: 0,
    player,
    bots,
    muros: [],
    loot,
    zoneX: (Math.random() - 0.5) * 10,
    zoneZ: (Math.random() - 0.5) * 10,
    zoneR: ZONE_RADII[0],
    zoneTx: 0,
    zoneTz: 0,
    zoneTr: ZONE_RADII[1],
    zoneT: 18,
    shrinking: false,
    stage: 0,
    nextId,
    kills: 0,
    place: 0,
    best,
    won: false,
    shake: 0,
    banner: "",
    bannerT: 0,
    tone: "ok",
    events: [],
  };
}

export const runtime = {
  sim: createSim(),
  keys: new Set<string>(),
  held: new Set<string>(),
  stick: { x: 0, y: 0, active: false },
  lookDx: 0,
  lookDy: 0,
  fireHeld: false,
  spaceWas: false,
  pulses: { jump: false, muro: false, med: false, swap: false, crouch: false, pulse: false },
  input: emptyInput(),
};

function emptyInput(): Input {
  return { mx: 0, mz: 0, lookDx: 0, lookDy: 0, fire: false, jump: false, muro: false, med: false, swap: false, crouch: false, pulse: false };
}

const listeners = new Set<() => void>();
let snap: HudSnap = toSnap(runtime.sim);
let sig = "";

function signature(s: Sim) {
  const p = s.player;
  const outside = Math.hypot(p.x - s.zoneX, p.z - s.zoneZ) > s.zoneR;
  return [
    s.phase,
    Math.ceil(p.hp),
    Math.ceil(p.armor),
    aliveCount(s),
    s.kills,
    s.place,
    s.best,
    p.gun,
    p.mag,
    p.reserve,
    p.reload > 0 ? 1 : 0,
    p.meds,
    p.muros,
    p.crouch ? 1 : 0,
    p.channel > 0 ? 1 : 0,
    outside ? 1 : 0,
    s.shrinking ? 1 : 0,
    Math.ceil(s.zoneT),
    s.bannerT > 0 ? s.banner : "",
    s.tone,
    Math.floor(s.playTime),
    p.pulseCd <= 0 ? 1 : 0,
    p.landed ? 1 : 0,
    s.won ? 1 : 0,
  ].join("|");
}

function aliveCount(s: Sim) {
  let n = s.player.alive ? 1 : 0;
  for (const b of s.bots) if (b.alive) n += 1;
  return n;
}

function toSnap(s: Sim): HudSnap {
  const p = s.player;
  return {
    phase: s.phase,
    hp: Math.max(0, Math.ceil(p.hp)),
    armor: Math.max(0, Math.ceil(p.armor)),
    alive: aliveCount(s),
    total: TOTAL,
    kills: s.kills,
    place: s.place,
    best: s.best,
    gun: p.gun,
    mag: p.mag,
    reserve: p.reserve,
    reloading: p.reload > 0,
    meds: p.meds,
    muros: p.muros,
    crouch: p.crouch,
    channel: p.channel > 0,
    outside: p.landed && Math.hypot(p.x - s.zoneX, p.z - s.zoneZ) > s.zoneR,
    shrinking: s.shrinking,
    zoneIn: Math.max(0, Math.ceil(s.zoneT)),
    banner: s.bannerT > 0 ? s.banner : "",
    tone: s.tone,
    playTime: Math.floor(s.playTime),
    pulseReady: p.pulseCd <= 0,
    landed: p.landed,
  };
}

export function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function getHud() {
  return snap;
}

export function getServerHud() {
  return SERVER_HUD;
}

export function publish(force = false) {
  const next = signature(runtime.sim);
  if (!force && next === sig) return;
  sig = next;
  snap = toSnap(runtime.sim);
  for (const listener of listeners) listener();
}

function edge(code: string) {
  const down = runtime.keys.has(code);
  const was = runtime.held.has(code);
  if (down) runtime.held.add(code);
  else runtime.held.delete(code);
  return down && !was;
}

export function readInput(): Input {
  const keys = runtime.keys;
  const stick = runtime.stick;
  let mx = 0;
  let mz = 0;
  if (stick.active) {
    mx = stick.x;
    mz = stick.y;
  } else {
    if (keys.has("KeyW") || keys.has("ArrowUp")) mz += 1;
    if (keys.has("KeyS") || keys.has("ArrowDown")) mz -= 1;
    if (keys.has("KeyA") || keys.has("ArrowLeft")) mx -= 1;
    if (keys.has("KeyD") || keys.has("ArrowRight")) mx += 1;
  }
  const len = Math.hypot(mx, mz);
  if (len > 1) {
    mx /= len;
    mz /= len;
  }
  if (Math.abs(mx) < 0.14) mx = 0;
  if (Math.abs(mz) < 0.14) mz = 0;
  const space = keys.has("Space");
  const input: Input = {
    mx,
    mz,
    lookDx: runtime.lookDx,
    lookDy: runtime.lookDy,
    fire: runtime.fireHeld || keys.has("KeyF"),
    jump: runtime.pulses.jump || (space && !runtime.spaceWas),
    muro: runtime.pulses.muro || edge("KeyG"),
    med: runtime.pulses.med || edge("KeyE"),
    swap: runtime.pulses.swap || edge("KeyQ"),
    crouch: runtime.pulses.crouch || edge("KeyC"),
    pulse: runtime.pulses.pulse || edge("KeyV"),
  };
  runtime.spaceWas = space;
  runtime.lookDx = 0;
  runtime.lookDy = 0;
  runtime.pulses.jump = false;
  runtime.pulses.muro = false;
  runtime.pulses.med = false;
  runtime.pulses.swap = false;
  runtime.pulses.crouch = false;
  runtime.pulses.pulse = false;
  runtime.input = input;
  return input;
}

export function tap(kind: "jump" | "muro" | "med" | "swap" | "crouch" | "pulse") {
  runtime.pulses[kind] = true;
}

export function begin() {
  const best = runtime.sim.best;
  const epoch = runtime.sim.epoch + 1;
  const fresh = createSim(best);
  fresh.epoch = epoch;
  fresh.phase = "drop";
  fresh.banner = "Queda livre";
  fresh.bannerT = 2.2;
  fresh.tone = "ok";
  runtime.sim = fresh;
  publish(true);
}

function say(sim: Sim, text: string, tone: "ok" | "bad" = "ok", t = 1.3) {
  sim.banner = text;
  sim.bannerT = t;
  sim.tone = tone;
}

function notePlace(sim: Sim, place: number) {
  sim.place = place;
  sim.phase = "over";
  if (sim.best === 0 || place < sim.best) {
    sim.best = place;
    saveBest(place);
  }
}

function basis(yaw: number) {
  return {
    fx: -Math.sin(yaw),
    fz: -Math.cos(yaw),
    rx: Math.cos(yaw),
    rz: -Math.sin(yaw),
  };
}

function clampArena(ent: { x: number; z: number }) {
  const d = Math.hypot(ent.x, ent.z);
  if (d > ARENA) {
    ent.x = (ent.x / d) * ARENA;
    ent.z = (ent.z / d) * ARENA;
  }
}

function overlapBox(x: number, z: number, box: { x: number; z: number; yaw: number; hx: number; hz: number }) {
  const { fx, fz, rx, rz } = basis(box.yaw);
  const lx = (x - box.x) * rx + (z - box.z) * rz;
  const lz = (x - box.x) * fx + (z - box.z) * fz;
  return Math.abs(lx) < box.hx && Math.abs(lz) < box.hz;
}

function pushOut(ent: { x: number; z: number }, box: { x: number; z: number; yaw: number; hx: number; hz: number }) {
  const { fx, fz, rx, rz } = basis(box.yaw);
  const lx = (ent.x - box.x) * rx + (ent.z - box.z) * rz;
  const lz = (ent.x - box.x) * fx + (ent.z - box.z) * fz;
  if (Math.abs(lx) >= box.hx || Math.abs(lz) >= box.hz) return;
  const px = box.hx - Math.abs(lx);
  const pz = box.hz - Math.abs(lz);
  if (px < pz) {
    const s = lx >= 0 ? 1 : -1;
    ent.x += rx * s * px;
    ent.z += rz * s * px;
  } else {
    const s = lz >= 0 ? 1 : -1;
    ent.x += fx * s * pz;
    ent.z += fz * s * pz;
  }
}

function pushSolids(sim: Sim, ent: { x: number; z: number }) {
  for (const c of COVERS) pushOut(ent, c);
  for (const m of sim.muros) pushOut(ent, { ...m, hx: 1.45, hz: 0.62 });
}

function rayBox(ox: number, oz: number, dx: number, dz: number, box: { x: number; z: number; yaw: number; hx: number; hz: number }, range: number) {
  const { fx, fz, rx, rz } = basis(box.yaw);
  const lx = (ox - box.x) * rx + (oz - box.z) * rz;
  const lz = (ox - box.x) * fx + (oz - box.z) * fz;
  const ldx = dx * rx + dz * rz;
  const ldz = dx * fx + dz * fz;
  let tmin = 0;
  let tmax = range;
  const slabs: [number, number, number][] = [
    [lx, ldx, box.hx],
    [lz, ldz, box.hz],
  ];
  for (const [p, d, h] of slabs) {
    if (Math.abs(d) < 1e-6) {
      if (p < -h || p > h) return null;
      continue;
    }
    let t1 = (-h - p) / d;
    let t2 = (h - p) / d;
    if (t1 > t2) {
      const s = t1;
      t1 = t2;
      t2 = s;
    }
    tmin = Math.max(tmin, t1);
    tmax = Math.min(tmax, t2);
    if (tmin > tmax) return null;
  }
  if (tmin < 0 || tmin > range) return null;
  return tmin;
}

function allFighters(sim: Sim) {
  return [sim.player, ...sim.bots];
}

function shoot(sim: Sim, f: Fighter, extraSpread: number) {
  const spec = GUNS[f.gun];
  if (f.reload > 0 || f.fireCd > 0 || !f.landed || !f.alive) return;
  if (f.mag <= 0) {
    if (f.reserve > 0) f.reload = spec.reload;
    return;
  }
  f.mag -= 1;
  f.fireCd = spec.rate;
  if (f.mag <= 0 && f.reserve > 0) f.reload = spec.reload;
  const { fx, fz } = basis(f.yaw);
  for (let i = 0; i < spec.pellets; i++) {
    const spread = (Math.random() - 0.5) * 2 * (spec.spread + extraSpread);
    const yaw = f.yaw + spread;
    const dx = -Math.sin(yaw);
    const dz = -Math.cos(yaw);
    let bestT = spec.range;
    let hit: Fighter | null = null;
    let hitMuro: Muro | null = null;
    for (const other of allFighters(sim)) {
      if (!other.alive || other.id === f.id || !other.landed) continue;
      const ox = other.x - f.x;
      const oz = other.z - f.z;
      const t = ox * dx + oz * dz;
      if (t < 0.4 || t > bestT) continue;
      const lat = Math.hypot(ox - dx * t, oz - dz * t);
      const rad = other.crouch ? 0.34 : 0.5;
      if (lat < rad) {
        bestT = t;
        hit = other;
        hitMuro = null;
      }
    }
    for (const c of COVERS) {
      const t = rayBox(f.x, f.z, dx, dz, c, bestT);
      if (t != null && t < bestT) {
        bestT = t;
        hit = null;
        hitMuro = null;
      }
    }
    for (const m of sim.muros) {
      const t = rayBox(f.x, f.z, dx, dz, { ...m, hx: 1.35, hz: 0.4 }, bestT);
      if (t != null && t < bestT) {
        bestT = t;
        hit = null;
        hitMuro = m;
      }
    }
    const x2 = f.x + dx * bestT;
    const z2 = f.z + dz * bestT;
    sim.events.push({ type: "shot", x: f.x + fx * 0.4, z: f.z + fz * 0.4, x2, z2 });
    if (hitMuro) {
      hitMuro.hp -= spec.dmg;
      sim.events.push({ type: "hit", x: x2, z: z2, x2, z2 });
    } else if (hit) {
      hurt(sim, hit, spec.dmg, f === sim.player);
      sim.events.push({ type: "hit", x: hit.x, z: hit.z, x2: hit.x, z2: hit.z });
      if (f !== sim.player) sim.shake = Math.max(sim.shake, hit === sim.player ? 0.35 : 0);
    }
  }
}

function hurt(sim: Sim, f: Fighter, dmg: number, byPlayer: boolean) {
  if (!f.alive) return;
  let left = dmg;
  if (f.armor > 0) {
    const used = Math.min(f.armor, left);
    f.armor -= used;
    left -= used;
  }
  f.hp -= left;
  if (f.hp > 0) return;
  f.hp = 0;
  f.alive = false;
  sim.events.push({ type: "kill", x: f.x, z: f.z, x2: f.x, z2: f.z });
  if (byPlayer && f !== sim.player) {
    sim.kills += 1;
    say(sim, `Abate · ${sim.kills}`, "ok", 1.1);
    sim.shake = 0.28;
  }
  if (f === sim.player) {
    const place = aliveCount(sim) + 1;
    say(sim, `Eliminado · #${place}`, "bad", 3);
    notePlace(sim, place);
  }
}

function placeMuro(sim: Sim, f: Fighter) {
  if (!f.landed || f.muros <= 0 || f.muroCd > 0 || !f.alive) return;
  const { fx, fz } = basis(f.yaw);
  const muro: Muro = {
    id: sim.nextId++,
    x: f.x + fx * 2.15,
    z: f.z + fz * 2.15,
    yaw: f.yaw,
    hp: 220,
  };
  if (Math.hypot(muro.x, muro.z) > ARENA - 0.5) return;
  sim.muros.push(muro);
  f.muros -= 1;
  f.muroCd = 0.4;
  sim.events.push({ type: "muro", x: muro.x, z: muro.z, x2: muro.x, z2: muro.z });
  if (f === sim.player) say(sim, "Muro no chão", "ok", 0.7);
}

function finishReload(f: Fighter) {
  const spec = GUNS[f.gun];
  const need = spec.mag - f.mag;
  const take = Math.min(need, f.reserve);
  f.mag += take;
  f.reserve -= take;
  f.reload = 0;
}

function giveGun(f: Fighter, gun: Gun) {
  const spec = GUNS[gun];
  f.gun = gun;
  f.mag = spec.mag;
  f.reserve += spec.mag;
  f.reload = 0;
  f.fireCd = 0.2;
}

function takeLoot(sim: Sim, f: Fighter, loot: Loot) {
  if (loot.kind === "ar" || loot.kind === "shotgun" || loot.kind === "pistol") {
    const gun = loot.kind;
    if (f.gun === "pistol" && !f.side) giveGun(f, gun);
    else if (!f.side) {
      const spec = GUNS[gun];
      f.side = gun;
      f.sideMag = spec.mag;
      f.sideReserve = spec.mag;
    } else {
      const prev = f.gun;
      const mag = f.mag;
      const reserve = f.reserve;
      giveGun(f, gun);
      f.side = prev;
      f.sideMag = mag;
      f.sideReserve = reserve;
    }
  } else if (loot.kind === "vest") {
    if (f.armor >= 100) return false;
    f.armor = 100;
  } else if (loot.kind === "med") {
    if (f.meds >= 4) return false;
    f.meds += 1;
  } else if (loot.kind === "muro") {
    if (f.muros >= 6) return false;
    f.muros += 1;
  } else if (f.reserve > 140) return false;
  else f.reserve += 36;
  sim.events.push({ type: "pickup", x: loot.x, z: loot.z, x2: loot.x, z2: loot.z });
  return true;
}

function pickupNear(sim: Sim, f: Fighter) {
  for (let i = sim.loot.length - 1; i >= 0; i--) {
    const loot = sim.loot[i];
    if (Math.hypot(loot.x - f.x, loot.z - f.z) > 1.35) continue;
    if (!takeLoot(sim, f, loot)) continue;
    sim.loot.splice(i, 1);
    if (f === sim.player) {
      const label =
        loot.kind === "vest" ? "Colete" : loot.kind === "med" ? "Kit" : loot.kind === "muro" ? "Muro" : loot.kind === "ammo" ? "Munição" : GUN_LABEL[loot.kind];
      say(sim, label, "ok", 0.8);
    }
    return;
  }
}

function zoneDamage(stage: number) {
  return [8, 14, 22, 34, 48][Math.min(stage, 4)];
}

function inZone(sim: Sim, x: number, z: number) {
  return Math.hypot(x - sim.zoneX, z - sim.zoneZ) <= sim.zoneR;
}

function stepZone(sim: Sim, dt: number) {
  sim.zoneT -= dt;
  if (!sim.shrinking && sim.zoneT <= 0 && sim.stage < ZONE_RADII.length - 1) {
    sim.shrinking = true;
    sim.zoneT = 8;
    sim.zoneTr = ZONE_RADII[sim.stage + 1];
    const a = Math.random() * Math.PI * 2;
    const reach = Math.max(0, sim.zoneR - sim.zoneTr - 1);
    sim.zoneTx = sim.zoneX + Math.cos(a) * Math.random() * reach;
    sim.zoneTz = sim.zoneZ + Math.sin(a) * Math.random() * reach;
    say(sim, "A zona está fechando", "bad", 1.6);
  } else if (sim.shrinking) {
    const k = Math.min(1, dt / Math.max(sim.zoneT, 0.05));
    sim.zoneR += (sim.zoneTr - sim.zoneR) * Math.min(1, dt * 0.35);
    sim.zoneX += (sim.zoneTx - sim.zoneX) * k;
    sim.zoneZ += (sim.zoneTz - sim.zoneZ) * k;
    if (sim.zoneT <= 0) {
      sim.shrinking = false;
      sim.zoneR = sim.zoneTr;
      sim.zoneX = sim.zoneTx;
      sim.zoneZ = sim.zoneTz;
      sim.stage += 1;
      sim.zoneT = sim.stage >= ZONE_RADII.length - 1 ? 99 : 14;
      say(sim, "Zona fechada", "ok", 1);
    }
  }
}

function stepFighterFall(f: Fighter, dt: number) {
  if (f.landed) return;
  f.y -= 9 * dt;
  const dx = f.landX - f.x;
  const dz = f.landZ - f.z;
  const d = Math.hypot(dx, dz) || 1;
  f.x += (dx / d) * 11 * dt;
  f.z += (dz / d) * 11 * dt;
  f.speed = 11;
  if (f.y <= 0) {
    f.y = 0;
    f.landed = true;
    f.vy = 0;
  }
}

function stepBot(sim: Sim, b: Bot, dt: number) {
  if (!b.alive) return;
  b.fireCd = Math.max(0, b.fireCd - dt);
  b.muroCd = Math.max(0, b.muroCd - dt);
  if (!b.landed) {
    stepFighterFall(b, dt);
    return;
  }
  if (b.reload > 0) {
    b.reload -= dt;
    if (b.reload <= 0) finishReload(b);
  }
  let foe: Fighter | null = null;
  let foeD = 22;
  for (const other of allFighters(sim)) {
    if (!other.alive || other.id === b.id || !other.landed) continue;
    const d = Math.hypot(other.x - b.x, other.z - b.z);
    if (d < foeD) {
      foe = other;
      foeD = d;
    }
  }
  const zx = sim.zoneX - b.x;
  const zz = sim.zoneZ - b.z;
  const zd = Math.hypot(zx, zz) || 1;
  let wx = 0;
  let wz = 0;
  if (!inZone(sim, b.x, b.z) || zd > sim.zoneR - 2.5) {
    wx = zx / zd;
    wz = zz / zd;
  } else if (foe) {
    const dx = foe.x - b.x;
    const dz = foe.z - b.z;
    const d = foeD || 1;
    b.yaw = Math.atan2(-dx, -dz);
    const side = b.id % 2 === 0 ? 1 : -1;
    const toward = d > 11 ? 0.65 : d < 4.5 ? -0.35 : 0.1;
    wx = (-dz / d) * side + (dx / d) * toward;
    wz = (dx / d) * side + (dz / d) * toward;
    if (foeD < 20) shoot(sim, b, 0.08);
    if (b.hp < 70 && b.muros > 0 && Math.random() < dt * 0.7) placeMuro(sim, b);
  } else {
    wx = Math.cos(sim.time * 0.45 + b.id) + zx / zd;
    wz = Math.sin(sim.time * 0.38 + b.id) + zz / zd;
    b.yaw = Math.atan2(-wx, -wz);
    if (b.gun === "pistol") pickupNear(sim, b);
  }
  const mag = Math.hypot(wx, wz) || 1;
  const sp = 6.4;
  b.x += (wx / mag) * sp * dt;
  b.z += (wz / mag) * sp * dt;
  b.speed = sp;
  pushSolids(sim, b);
  clampArena(b);
  for (const other of sim.bots) {
    if (other.id === b.id || !other.alive) continue;
    const dx = b.x - other.x;
    const dz = b.z - other.z;
    const d = Math.hypot(dx, dz);
    if (d > 0.01 && d < 1.25) {
      b.x += (dx / d) * (1.25 - d) * 0.5;
      b.z += (dz / d) * (1.25 - d) * 0.5;
    }
  }
  if (b.landed && !inZone(sim, b.x, b.z)) hurt(sim, b, zoneDamage(sim.stage) * dt, false);
}

function checkWin(sim: Sim) {
  if (!sim.player.alive || sim.phase === "over") return;
  if (aliveCount(sim) === 1) {
    sim.won = true;
    say(sim, "Último de pé", "ok", 4);
    notePlace(sim, 1);
  }
}

export function step(sim: Sim, dt: number, input: Input) {
  sim.time += dt;
  sim.shake = Math.max(0, sim.shake - dt * 1.6);
  if (sim.bannerT > 0) sim.bannerT = Math.max(0, sim.bannerT - dt);
  if (sim.events.length > 32) sim.events.splice(0, sim.events.length - 32);
  if (sim.phase !== "drop" && sim.phase !== "play") return;

  const p = sim.player;
  p.yaw -= input.lookDx * 0.0048;
  p.pitch = Math.max(-0.42, Math.min(0.6, p.pitch - input.lookDy * 0.0034));
  p.fireCd = Math.max(0, p.fireCd - dt);
  p.muroCd = Math.max(0, p.muroCd - dt);
  p.pulse = Math.max(0, p.pulse - dt);
  p.pulseCd = Math.max(0, p.pulseCd - dt);

  if (p.alive) {
    if (!p.landed) {
      const { fx, fz, rx, rz } = basis(p.yaw);
      const spd = 13;
      p.x += (rx * input.mx + fx * input.mz) * spd * dt;
      p.z += (rz * input.mx + fz * input.mz) * spd * dt;
      p.speed = spd * Math.hypot(input.mx, input.mz);
      p.y -= 9 * dt;
      pushSolids(sim, p);
      clampArena(p);
      if (p.y <= 0) {
        p.y = 0;
        p.landed = true;
        sim.phase = "play";
        say(sim, "No chão. Loot e zona.", "ok", 1.8);
      }
    } else {
      if (input.crouch) p.crouch = !p.crouch;
      if (input.swap && p.side) {
        const gun = p.gun;
        const mag = p.mag;
        const reserve = p.reserve;
        p.gun = p.side;
        p.mag = p.sideMag;
        p.reserve = p.sideReserve;
        p.side = gun;
        p.sideMag = mag;
        p.sideReserve = reserve;
        p.reload = 0;
        say(sim, GUN_LABEL[p.gun], "ok", 0.7);
      }
      if (input.pulse && p.pulseCd <= 0) {
        p.pulse = 4;
        p.pulseCd = 16;
        say(sim, "Pulso — inimigos no mapa", "ok", 1.2);
      }
      const moving = Math.hypot(input.mx, input.mz);
      if (p.channel > 0 && moving > 0.2) {
        p.channel = 0;
        say(sim, "Kit cancelado", "bad", 0.6);
      } else if (p.channel > 0) {
        p.channel -= dt;
        if (p.channel <= 0) {
          p.channel = 0;
          p.hp = Math.min(200, p.hp + 90);
          p.meds -= 1;
          say(sim, "Kit usado", "ok", 0.8);
        }
      } else if (input.med && p.meds > 0 && p.hp < 200) {
        p.channel = 1.15;
        say(sim, "Usando kit…", "ok", 1.15);
      }
      const { fx, fz, rx, rz } = basis(p.yaw);
      const run = moving > 0.82 && !p.crouch;
      const spd = p.crouch ? 4.3 : run ? 8.7 : 6.3;
      const vx = (rx * input.mx + fx * input.mz) * spd;
      const vz = (rz * input.mx + fz * input.mz) * spd;
      p.x += vx * dt;
      p.z += vz * dt;
      p.speed = Math.hypot(vx, vz);
      if (input.jump && p.y <= 0.05 && !p.crouch) p.vy = 6.3;
      p.vy -= 22 * dt;
      p.y += p.vy * dt;
      if (p.y <= 0) {
        p.y = 0;
        p.vy = 0;
      }
      pushSolids(sim, p);
      clampArena(p);
      if (p.reload > 0) {
        p.reload -= dt;
        if (p.reload <= 0) finishReload(p);
      }
      if (input.muro) placeMuro(sim, p);
      if (input.fire && p.channel <= 0) shoot(sim, p, p.crouch ? 0.01 : 0);
      pickupNear(sim, p);
    }
  }

  for (const b of sim.bots) stepBot(sim, b, dt);

  if (sim.phase === "play") {
    sim.playTime += dt;
    stepZone(sim, dt);
    if (p.alive && p.landed && !inZone(sim, p.x, p.z)) {
      hurt(sim, p, zoneDamage(sim.stage) * dt, false);
      if (p.alive && sim.bannerT <= 0) say(sim, "Fora da zona", "bad", 0.6);
    }
  }

  for (let i = sim.muros.length - 1; i >= 0; i--) {
    if (sim.muros[i].hp <= 0) sim.muros.splice(i, 1);
  }
  checkWin(sim);
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      getX: () => number;
      getZ: () => number;
      setKeys: (codes: string[]) => void;
    };
  }
}
