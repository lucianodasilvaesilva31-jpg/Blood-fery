import * as THREE from "three";
import { playEvent } from "@/game/audio";
import {
  ARENA,
  COVERS,
  publish,
  readInput,
  runtime,
  step,
  type Fighter,
  type FxEvent,
  type Loot,
  type Muro,
} from "@/game/sim";

const HALL = [
  { x: 8, z: 16, color: 0x3dbe8c },
  { x: -16, z: 12, color: 0xe23b3b },
  { x: 18, z: -8, color: 0x3b6fe2 },
  { x: -6, z: -16, color: 0xe7a23a },
];

const NAV = new Set(["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"]);

const LOOT_COLOR: Record<Loot["kind"], number> = {
  ar: 0xe7a23a,
  shotgun: 0xe23b3b,
  pistol: 0xc4b59a,
  vest: 0x3dbe8c,
  med: 0xf3ece3,
  muro: 0x7fd4cf,
  ammo: 0xd2b48a,
};

export function mount(canvas: HTMLCanvasElement, wrap: HTMLElement) {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: "high-performance",
  });
  renderer.setClearColor(0x1a120e);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.NoToneMapping;

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x1a120e, 0.012);
  const camera = new THREE.PerspectiveCamera(58, 1, 0.1, 240);
  camera.position.set(0, 8, 14);
  camera.lookAt(0, 1, 0);

  scene.add(new THREE.HemisphereLight(0xfff1dd, 0x8a4030, 1.25));
  const sun = new THREE.DirectionalLight(0xfff0d2, 2);
  sun.position.set(18, 28, 10);
  scene.add(sun);
  const fill = new THREE.DirectionalLight(0x9eb6d8, 0.55);
  fill.position.set(-12, 10, -8);
  scene.add(fill);

  // Ocean surrounds the playable island; the sandy shoreline blends into the terrain.
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(260, 260),
    new THREE.MeshStandardMaterial({ color: 0x123f55, roughness: 0.32, metalness: 0.12 }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = -0.16;
  scene.add(floor);

  const ground = new THREE.Mesh(new THREE.CircleGeometry(ARENA + 2, 96), groundMaterial());
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);
  addIslandLandmarks(scene);
  scene.add(makeStars());
  for (const planet of makePlanets()) scene.add(planet);
  scene.add(makeWreck());

  const poleGeo = new THREE.CylinderGeometry(0.06, 0.08, 2.1, 6);
  const poleMat = new THREE.MeshStandardMaterial({ color: 0x2a211c, roughness: 0.75 });
  const lampGeo = new THREE.SphereGeometry(0.34, 12, 10);
  for (const hall of HALL) {
    const g = new THREE.Group();
    const post = new THREE.Mesh(poleGeo, poleMat);
    post.position.y = 1.05;
    const lamp = new THREE.Mesh(lampGeo, new THREE.MeshBasicMaterial({ color: hall.color }));
    lamp.position.y = 2.15;
    g.add(post, lamp);
    g.position.set(hall.x, 0, hall.z);
    scene.add(g);
  }

  const rockGeo = new THREE.IcosahedronGeometry(1, 0);
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x5a3224, roughness: 0.92, flatShading: true });
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2 + 0.3;
    const rock = new THREE.Mesh(rockGeo, rockMat);
    const s = 0.55 + (i % 3) * 0.35;
    rock.scale.setScalar(s);
    rock.position.set(Math.cos(a) * (ARENA - 1.2), s * 0.3, Math.sin(a) * (ARENA - 1.2));
    scene.add(rock);
  }

  const coverMat = new THREE.MeshStandardMaterial({ color: 0x6a5344, roughness: 0.8 });
  const coverGeo = new THREE.BoxGeometry(1, 1, 1);
  for (const cover of COVERS) {
    const mesh = new THREE.Mesh(coverGeo, coverMat);
    mesh.scale.set(cover.hx * 2, 1.3, cover.hz * 2);
    mesh.position.set(cover.x, 0.65, cover.z);
    mesh.rotation.y = cover.yaw;
    scene.add(mesh);
  }

  const zoneRing = new THREE.Mesh(
    new THREE.RingGeometry(0.985, 1.02, 96),
    new THREE.MeshBasicMaterial({ color: 0x3ec6c0, side: THREE.DoubleSide }),
  );
  zoneRing.rotation.x = -Math.PI / 2;
  zoneRing.position.y = 0.18;
  scene.add(zoneRing);
  const zoneWall = new THREE.Mesh(
    new THREE.CylinderGeometry(1, 1, 8, 72, 1, true),
    new THREE.MeshBasicMaterial({
      color: 0x146e78,
      transparent: true,
      opacity: 0.22,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  zoneWall.position.y = 4;
  scene.add(zoneWall);

  const player = makeFighter(0xe7a23a, false);
  scene.add(player.group);
  const bots = new Map<number, ReturnType<typeof makeFighter>>();
  const loot = new Map<number, THREE.Mesh>();
  const muros = new Map<number, THREE.Mesh>();
  const lootGeo = new THREE.OctahedronGeometry(0.38, 0);
  const muroGeo = new THREE.BoxGeometry(2.7, 1.7, 0.38);
  const muroMat = new THREE.MeshStandardMaterial({
    color: 0xb7efe9,
    emissive: 0x2a8a86,
    emissiveIntensity: 0.35,
    transparent: true,
    opacity: 0.88,
    roughness: 0.25,
  });
  const tracers = makeTracers();
  scene.add(tracers.group);

  const desired = new THREE.Vector3();
  const look = new THREE.Vector3();
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let epoch = runtime.sim.epoch;
  let last = performance.now();
  let raf = 0;
  let alive = true;

  const onKeyDown = (e: KeyboardEvent) => {
    runtime.keys.add(e.code);
    if (runtime.sim.phase !== "boot" && NAV.has(e.code)) e.preventDefault();
  };
  const onKeyUp = (e: KeyboardEvent) => runtime.keys.delete(e.code);
  const onBlur = () => {
    runtime.keys.clear();
    runtime.fireHeld = false;
  };
  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", onBlur);

  window.__controlsTest = {
    getYaw: () => runtime.sim.player.yaw,
    getSpeed: () => runtime.sim.player.speed,
    getX: () => runtime.sim.player.x,
    getZ: () => runtime.sim.player.z,
    setKeys: (codes: string[]) => {
      runtime.keys = new Set(codes);
    },
  };

  const resize = () => {
    const w = wrap.clientWidth || 1;
    const h = wrap.clientHeight || 1;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, w < 700 ? 1.5 : 1.75));
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  };
  resize();
  const observer = new ResizeObserver(resize);
  observer.observe(wrap);

  const frame = (now: number) => {
    if (!alive) return;
    raf = requestAnimationFrame(frame);
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    const sim = runtime.sim;
    if (sim.epoch !== epoch) {
      for (const mesh of bots.values()) mesh.group.removeFromParent();
      bots.clear();
      for (const mesh of loot.values()) mesh.removeFromParent();
      loot.clear();
      for (const mesh of muros.values()) mesh.removeFromParent();
      muros.clear();
      epoch = sim.epoch;
    }
    const input = readInput();
    step(sim, dt, input);
    publish();

    const p = sim.player;
    poseFighter(player, p, sim.time);
    player.group.visible = p.alive;
    syncBots(scene, bots, sim.bots, sim.time);
    syncLoot(scene, loot, lootGeo, sim.loot, sim.time);
    syncMuros(scene, muros, muroGeo, muroMat, sim.muros);
    for (const ev of sim.events) {
      if (ev.type === "shot") tracers.spawn(ev);
      playEvent(ev.type);
    }
    sim.events.length = 0;
    tracers.tick(dt);

    zoneRing.position.set(sim.zoneX, 0.18, sim.zoneZ);
    zoneRing.scale.set(sim.zoneR, sim.zoneR, 1);
    zoneWall.position.set(sim.zoneX, 4, sim.zoneZ);
    zoneWall.scale.set(sim.zoneR, 1, sim.zoneR);

    const { fx, fz } = basis(p.yaw);
    const back = p.landed ? 5.1 : 11;
    const eye = (p.crouch ? 1.05 : 1.5) + p.y;
    const follow = 1 - Math.exp(-(reduced ? 16 : p.landed ? 7 : 2.2) * dt);
    if (sim.phase === "boot") {
      const ang = reduced ? 0.6 : sim.time * 0.15;
      desired.set(Math.sin(ang) * 18, 9, Math.cos(ang) * 18);
      look.set(0, 1, 0);
    } else {
      const cos = Math.cos(p.pitch);
      desired.set(p.x - fx * back * cos, eye + 0.45 + Math.sin(p.pitch) * back * 0.75, p.z - fz * back * cos);
      look.set(p.x + fx * 8, eye - 0.1 + Math.sin(p.pitch) * 6, p.z + fz * 8);
    }
    camera.position.lerp(desired, follow);
    if (sim.shake > 0 && !reduced) {
      camera.position.x += (Math.random() - 0.5) * sim.shake;
      camera.position.y += (Math.random() - 0.5) * sim.shake * 0.4;
    }
    camera.lookAt(look);
    renderer.render(scene, camera);
  };
  raf = requestAnimationFrame(frame);

  return () => {
    alive = false;
    cancelAnimationFrame(raf);
    observer.disconnect();
    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("keyup", onKeyUp);
    window.removeEventListener("blur", onBlur);
    if (window.__controlsTest) delete window.__controlsTest;
    renderer.dispose();
    scene.traverse((node) => {
      const mesh = node as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const mat = mesh.material;
      if (!mat) return;
      if (Array.isArray(mat)) for (const m of mat) m.dispose();
      else mat.dispose();
    });
  };
}

function basis(yaw: number) {
  return { fx: -Math.sin(yaw), fz: -Math.cos(yaw) };
}

function makeFighter(accent: number, dark: boolean) {
  const group = new THREE.Group();
  const cloth = new THREE.MeshStandardMaterial({ color: dark ? 0x29343a : 0x354d43, roughness: 0.86 });
  const pants = new THREE.MeshStandardMaterial({ color: dark ? 0x20252a : 0x292f32, roughness: 0.92 });
  const skin = new THREE.MeshStandardMaterial({ color: 0xa96f4c, roughness: 0.72 });
  const metal = new THREE.MeshStandardMaterial({ color: 0x20262a, metalness: 0.62, roughness: 0.36 });
  const gear = new THREE.MeshStandardMaterial({ color: 0x62513b, roughness: 0.9 });
  const band = new THREE.MeshStandardMaterial({ color: accent, emissive: accent, emissiveIntensity: 0.18, roughness: 0.48 });
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.28, 4, 8), cloth);
  torso.position.y = 1.08;
  torso.scale.set(1, 1, 0.72);
  const vest = new THREE.Mesh(new THREE.BoxGeometry(0.43, 0.34, 0.27), gear);
  vest.position.set(0, 1.1, -0.015);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.145, 12, 10), skin);
  head.position.y = 1.52;
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.62), metal);
  helmet.position.y = 1.58;
  const hips = new THREE.Mesh(new THREE.BoxGeometry(0.37, 0.16, 0.23), band);
  hips.position.y = 0.76;
  const legGeo = new THREE.CapsuleGeometry(0.075, 0.32, 3, 6);
  const legL = new THREE.Mesh(legGeo, pants);
  legL.position.set(-0.115, 0.39, 0);
  const legR = new THREE.Mesh(legGeo, pants);
  legR.position.set(0.115, 0.39, 0);
  const bootGeo = new THREE.BoxGeometry(0.15, 0.1, 0.22);
  const bootL = new THREE.Mesh(bootGeo, metal); bootL.position.set(-0.115, 0.09, 0.035);
  const bootR = new THREE.Mesh(bootGeo, metal); bootR.position.set(0.115, 0.09, 0.035);
  const armGeo = new THREE.CapsuleGeometry(0.065, 0.28, 3, 6);
  const armL = new THREE.Mesh(armGeo, cloth); armL.position.set(-0.29, 1.04, 0.08); armL.rotation.z = -0.22;
  const armR = new THREE.Mesh(armGeo, cloth); armR.position.set(0.29, 1.04, 0.16); armR.rotation.z = 0.28;
  const backpack = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.34, 0.14), gear);
  backpack.position.set(0, 1.08, -0.22);
  const gun = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.13, 0.48), metal);
  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.25, 7), metal);
  barrel.rotation.x = Math.PI / 2; barrel.position.z = 0.34;
  const stock = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.1, 0.18), gear); stock.position.z = -0.25;
  gun.add(body, barrel, stock); gun.position.set(0.2, 1.08, 0.34); gun.rotation.x = -0.08;
  group.add(torso, vest, head, helmet, hips, legL, legR, bootL, bootR, armL, armR, backpack, gun);
  return { group, legL, legR, hips };
}

function addIslandLandmarks(scene: THREE.Scene) {
  const houseWall = new THREE.MeshStandardMaterial({ color: 0xd4c4a1, roughness: 0.92 });
  const roofMat = new THREE.MeshStandardMaterial({ color: 0x8b4935, roughness: 0.88 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x34383a, roughness: 0.8 });
  const windowMat = new THREE.MeshStandardMaterial({ color: 0x73b7c1, emissive: 0x173b43, roughness: 0.28 });
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x68472d, roughness: 0.96 });
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x34734c, roughness: 0.9, flatShading: true });
  const houses = [
    { x: -19, z: -12, w: 5.2, d: 4.4, rot: 0.15 }, { x: -13, z: -16, w: 4.3, d: 4.0, rot: -0.2 },
    { x: 18, z: 13, w: 5.4, d: 4.5, rot: -0.35 }, { x: 23, z: 7, w: 4.2, d: 3.8, rot: 0.2 },
    { x: -3, z: 22, w: 6.2, d: 4.6, rot: 0.1 }, { x: 10, z: -22, w: 5.5, d: 4.2, rot: -0.25 },
  ];
  for (const h of houses) {
    const g = new THREE.Group();
    const base = new THREE.Mesh(new THREE.BoxGeometry(h.w, 2.35, h.d), houseWall); base.position.y = 1.18;
    const roof = new THREE.Mesh(new THREE.ConeGeometry(Math.max(h.w, h.d) * 0.78, 1.65, 4), roofMat); roof.position.y = 3.15; roof.rotation.y = Math.PI / 4;
    const door = new THREE.Mesh(new THREE.BoxGeometry(0.78, 1.45, 0.08), dark); door.position.set(0, 0.73, h.d / 2 + 0.045);
    const win1 = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.62, 0.07), windowMat); win1.position.set(-h.w * 0.28, 1.45, h.d / 2 + 0.05);
    const win2 = win1.clone(); win2.position.x = h.w * 0.28;
    g.add(base, roof, door, win1, win2); g.position.set(h.x, 0, h.z); g.rotation.y = h.rot; scene.add(g);
  }
  // Palm groves around the shoreline and between settlements.
  for (let i = 0; i < 42; i++) {
    const angle = i * 2.399963;
    const radius = 25 + (i % 7) * 2.35;
    const x = Math.cos(angle) * radius, z = Math.sin(angle) * radius;
    if (Math.hypot(x, z) > ARENA - 2) continue;
    const palm = new THREE.Group();
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.22, 2.7, 7), trunkMat); trunk.position.y = 1.35; trunk.rotation.z = 0.08 * Math.sin(i);
    palm.add(trunk);
    for (let j = 0; j < 6; j++) {
      const frond = new THREE.Mesh(new THREE.ConeGeometry(0.22, 2.2, 5), leafMat);
      const a = j * Math.PI / 3; frond.position.set(Math.cos(a) * 0.75, 2.62, Math.sin(a) * 0.75); frond.rotation.z = Math.cos(a) * 0.9; frond.rotation.x = Math.sin(a) * 0.9; palm.add(frond);
    }
    palm.position.set(x, 0, z); palm.scale.setScalar(0.8 + (i % 3) * 0.12); scene.add(palm);
  }
  // Simple paved roads visually connect the island settlements.
  const roadMat = new THREE.MeshStandardMaterial({ color: 0x77766c, roughness: 1 });
  const roads = [{ x: -11, z: 1, w: 2.5, d: 35, r: -0.28 }, { x: 5, z: 2, w: 2.2, d: 42, r: 0.18 }];
  for (const r of roads) { const road = new THREE.Mesh(new THREE.BoxGeometry(r.w, 0.035, r.d), roadMat); road.position.set(r.x, 0.015, r.z); road.rotation.y = r.r; scene.add(road); }
}

function poseFighter(view: ReturnType<typeof makeFighter>, f: Fighter, time: number) {
  const bob = f.landed ? Math.sin(time * (f.speed > 4 ? 12 : 2)) * Math.min(0.08, f.speed * 0.01) : 0;
  view.group.position.set(f.x, f.y + (f.crouch ? -0.32 : 0) + bob, f.z);
  view.group.rotation.y = f.yaw + Math.PI;
  view.group.visible = f.alive;
  const swing = Math.sin(time * 11) * Math.min(0.7, f.speed / 7);
  view.legL.rotation.x = swing;
  view.legR.rotation.x = -swing;
  const mat = view.hips.material as THREE.MeshStandardMaterial;
  mat.emissive.setHex(f.armor > 0 ? 0x3dbe8c : 0xe7a23a);
}

function syncBots(scene: THREE.Scene, map: Map<number, ReturnType<typeof makeFighter>>, list: Fighter[], time: number) {
  const alive = new Set(list.filter((b) => b.alive).map((b) => b.id));
  for (const [id, view] of map) {
    if (alive.has(id)) continue;
    view.group.removeFromParent();
    map.delete(id);
  }
  for (const bot of list) {
    if (!bot.alive) continue;
    let view = map.get(bot.id);
    if (!view) {
      view = makeFighter(0xd4533a, true);
      scene.add(view.group);
      map.set(bot.id, view);
    }
    poseFighter(view, bot, time + bot.id);
  }
}

function syncLoot(scene: THREE.Scene, map: Map<number, THREE.Mesh>, geo: THREE.BufferGeometry, list: Loot[], time: number) {
  const alive = new Set(list.map((item) => item.id));
  for (const [id, mesh] of map) {
    if (alive.has(id)) continue;
    mesh.removeFromParent();
    map.delete(id);
  }
  for (const item of list) {
    let mesh = map.get(item.id);
    if (!mesh) {
      mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: LOOT_COLOR[item.kind] }));
      scene.add(mesh);
      map.set(item.id, mesh);
    }
    mesh.position.set(item.x, 0.55 + Math.sin(time * 2.4 + item.id) * 0.08, item.z);
    mesh.rotation.y = time * 0.8;
  }
}

function syncMuros(scene: THREE.Scene, map: Map<number, THREE.Mesh>, geo: THREE.BufferGeometry, mat: THREE.Material, list: Muro[]) {
  const alive = new Set(list.map((m) => m.id));
  for (const [id, mesh] of map) {
    if (alive.has(id)) continue;
    mesh.removeFromParent();
    map.delete(id);
  }
  for (const muro of list) {
    let mesh = map.get(muro.id);
    if (!mesh) {
      mesh = new THREE.Mesh(geo, mat);
      scene.add(mesh);
      map.set(muro.id, mesh);
    }
    mesh.position.set(muro.x, 0.85, muro.z);
    mesh.rotation.y = muro.yaw;
    mesh.scale.y = Math.max(0.35, muro.hp / 220);
  }
}

function makeTracers() {
  const group = new THREE.Group();
  const geo = new THREE.BoxGeometry(0.045, 0.045, 1);
  const mat = new THREE.MeshBasicMaterial({ color: 0xffe3a3 });
  const pool = Array.from({ length: 28 }, () => {
    const mesh = new THREE.Mesh(geo, mat);
    mesh.visible = false;
    mesh.userData.life = 0;
    group.add(mesh);
    return mesh;
  });
  return {
    group,
    spawn(ev: FxEvent) {
      const mesh = pool.find((item) => item.userData.life <= 0);
      if (!mesh) return;
      const dx = ev.x2 - ev.x;
      const dz = ev.z2 - ev.z;
      const len = Math.hypot(dx, dz) || 0.001;
      mesh.visible = true;
      mesh.userData.life = 0.07;
      mesh.scale.z = len;
      mesh.position.set((ev.x + ev.x2) / 2, 1.15, (ev.z + ev.z2) / 2);
      mesh.lookAt(ev.x2, 1.15, ev.z2);
    },
    tick(dt: number) {
      for (const mesh of pool) {
        if (mesh.userData.life <= 0) continue;
        mesh.userData.life -= dt;
        if (mesh.userData.life <= 0) mesh.visible = false;
      }
    },
  };
}

function groundMaterial() {
  return new THREE.ShaderMaterial({
    vertexShader: `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      precision mediump float;
      varying vec2 vUv;
      void main() {
        vec2 p = vUv * 2.0 - 1.0;
        float r = length(p);
        float rings = smoothstep(0.02, 0.0, abs(fract(r * 10.0) - 0.12));
        vec3 lo = vec3(0.12, 0.34, 0.20);
        vec3 hi = vec3(0.28, 0.48, 0.27);
        vec3 col = mix(lo, hi, r);
        col = mix(col, col * 0.78, rings);
        float rim = smoothstep(0.91, 1.0, r);
        col = mix(col, vec3(0.77, 0.68, 0.43), rim);
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
}

function makeStars() {
  const n = 500;
  const pos = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const r = 80 + Math.random() * 30;
    const th = Math.random() * Math.PI * 2;
    const ph = Math.acos(2 * Math.random() - 1);
    pos[i * 3] = r * Math.sin(ph) * Math.cos(th);
    pos[i * 3 + 1] = Math.abs(r * Math.cos(ph));
    pos[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  return new THREE.Points(
    geo,
    new THREE.PointsMaterial({ color: 0xfff6e8, size: 1.2, sizeAttenuation: true, fog: false }),
  );
}

function makePlanets() {
  const geo = new THREE.IcosahedronGeometry(1, 1);
  const specs = [
    { p: [-40, 16, -48], s: 8, c: 0xc46248, e: 0x6a2818 },
    { p: [48, 12, -36], s: 5, c: 0x9aafc0, e: 0x334450 },
    { p: [-28, 22, 46], s: 3.4, c: 0xe6d2b0, e: 0x6a5840 },
  ];
  return specs.map((spec) => {
    const mesh = new THREE.Mesh(
      geo,
      new THREE.MeshStandardMaterial({
        color: spec.c,
        emissive: spec.e,
        emissiveIntensity: 0.7,
        flatShading: true,
        roughness: 0.8,
      }),
    );
    mesh.position.set(spec.p[0], spec.p[1], spec.p[2]);
    mesh.scale.setScalar(spec.s);
    return mesh;
  });
}

function makeWreck() {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0xb7aa9c, metalness: 0.4, roughness: 0.4 });
  const hull = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.38, 3.4), mat);
  hull.position.y = 0.32;
  const fin = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.08, 0.55), mat);
  fin.position.set(0, 0.5, -1.15);
  g.add(hull, fin);
  g.position.set(14, 0, -6);
  g.rotation.set(0.15, 0.7, 0.42);
  return g;
}
