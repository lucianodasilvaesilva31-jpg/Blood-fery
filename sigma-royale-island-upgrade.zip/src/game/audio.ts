let ctx: AudioContext | null = null;

export function unlockAudio() {
  if (typeof window === "undefined") return;
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AC) return;
  if (!ctx) ctx = new AC();
  void ctx.resume();
}

function tone(freq: number, dur: number, type: OscillatorType, gain: number) {
  if (!ctx) return;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const amp = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, now);
  amp.gain.setValueAtTime(gain, now);
  amp.gain.exponentialRampToValueAtTime(0.0001, now + dur);
  osc.connect(amp);
  amp.connect(ctx.destination);
  osc.start(now);
  osc.stop(now + dur + 0.02);
}

export function playEvent(type: "shot" | "hit" | "kill" | "pickup" | "muro") {
  if (type === "shot") {
    tone(210, 0.05, "square", 0.03);
    tone(90, 0.07, "sawtooth", 0.02);
    return;
  }
  if (type === "hit") {
    tone(140, 0.06, "triangle", 0.03);
    return;
  }
  if (type === "kill") {
    tone(320, 0.08, "square", 0.03);
    tone(480, 0.1, "triangle", 0.025);
    return;
  }
  if (type === "muro") {
    tone(180, 0.09, "triangle", 0.04);
    return;
  }
  tone(620, 0.07, "sine", 0.035);
}
